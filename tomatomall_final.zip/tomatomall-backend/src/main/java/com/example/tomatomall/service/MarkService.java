package com.example.tomatomall.service;

import com.example.tomatomall.configure.MarkStar;

public interface MarkService {
    String createMark(Integer productId, MarkStar markStar);
    String deleteMark(Integer productId);
    String changeMark(Integer productId, MarkStar markStar);
    String updateProductMark(Integer productId);
    String getMyProductMark(Integer productId);
}

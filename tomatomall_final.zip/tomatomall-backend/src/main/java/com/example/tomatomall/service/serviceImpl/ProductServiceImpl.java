package com.example.tomatomall.service.serviceImpl;

import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.Product;
import com.example.tomatomall.po.Stockpile;
import com.example.tomatomall.repository.ProductRepository;
import com.example.tomatomall.repository.StockpileRepository;
import com.example.tomatomall.service.ProductService;
import com.example.tomatomall.vo.ProductVO;
import com.example.tomatomall.po.Specification;
import com.example.tomatomall.repository.SpecificationRepository;
import com.example.tomatomall.vo.SpecificationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;


@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductRepository productRepository;

    @Autowired
    SpecificationRepository specificationRepository;

    @Autowired
    StockpileRepository stockpileRepository;

    //获取全部商品
    @Override
    public List<ProductVO> getAllProducts(){
        List<Product> products = productRepository.findAll();
        return products.stream()
                .map(product -> {
                    ProductVO productVO = product.toVO();
                    List<Specification> specifications =  specificationRepository.findByProductId(product.getId());
                    List<SpecificationVO> specificationVOs = specifications.stream()
                            .map(Specification::toVO)
                            .collect(Collectors.toList());
                    productVO.setSpecifications(specificationVOs);
                    return productVO;
                })
                .collect(Collectors.toList());
    }

    //获取特定id的商品
    @Override
    public ProductVO getTheProduct(Integer id){
        if(id == null) throw TomatoMallException.productNotExists();
        Product product = productRepository.findById(id).orElse(null);
        if(product == null) throw TomatoMallException.productNotExists();
        List<Specification> specifications = specificationRepository.findByProductId(product.getId());
        List<SpecificationVO> specificationVOs = specifications.stream()
                .map(Specification::toVO)
                .collect(Collectors.toList());
        ProductVO productVO = product.toVO();
        productVO.setSpecifications(specificationVOs);
        return productVO;
    }

    //更新商品信息
    @Override
    @Transactional
    public String updateProductInfo(ProductVO productVO){
        if(productVO.getId() == null) throw TomatoMallException.idNotMatch();
        Product product = productRepository.findById(productVO.getId()).orElse(null);
        if(product == null) throw TomatoMallException.productNotExists();
        product.setTitle(productVO.getTitle());
        product.setPrice(productVO.getPrice());
        product.setRate(productVO.getRate());
        if(productVO.getDescription() != null) product.setDescription(productVO.getDescription());
        if(productVO.getDetail() != null) product.setDetail(productVO.getDetail());
        if(productVO.getCover() != null) product.setCover(productVO.getCover());
        productRepository.save(product);
        if(productVO.getSpecifications() != null){
            for(SpecificationVO sp: productVO.getSpecifications()){
                if(!sp.getProductId().equals(productVO.getId())) throw TomatoMallException.idNotMatch();
            }
            specificationRepository.deleteByProductId(productVO.getId());
            List<Specification> newSpecifications = productVO.getSpecifications().stream()
                    .map(SpecificationVO::toPO)
                    .collect(Collectors.toList());
            specificationRepository.saveAll(newSpecifications);
        }
        return "更新成功";
    }

    //增加商品
    @Override
    public ProductVO addProduct(ProductVO productVO){
        Product product = productRepository.findByTitle(productVO.getTitle());
        if(product != null) throw TomatoMallException.productAlreadyExists();
        Product newproduct = productVO.toPO();
        productRepository.save(newproduct);
        Stockpile stockpile = new Stockpile();
        stockpile.setAmount(0);
        stockpile.setProductId(newproduct.getId());
        stockpile.setFrozen(0);
        stockpileRepository.save(stockpile);
        return newproduct.toVO();
    }

    //删除商品
    @Override
    @Transactional
    public String deleteProduct(Integer id){
        if(id == null) throw TomatoMallException.idNotMatch();
        Product product = productRepository.findById(id).orElse(null);
        if(product == null) throw TomatoMallException.productNotExists();
        stockpileRepository.deleteByProductId(id);
        specificationRepository.deleteByProductId(id);
        productRepository.deleteById(id);
        return "删除成功";
    }
}

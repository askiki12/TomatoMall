package com.example.tomatomall.service.serviceImpl;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradePagePayModel;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.response.AlipayTradePagePayResponse;
import com.example.tomatomall.configure.AliPayHtml;
import com.example.tomatomall.configure.LockConfigure;
import com.example.tomatomall.configure.OrderStatus;
import com.example.tomatomall.configure.RetOrderInfo;
import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.*;
import com.example.tomatomall.repository.*;
import com.example.tomatomall.service.CartService;
import com.example.tomatomall.service.OrderService;
import com.example.tomatomall.service.ProductService;
import com.example.tomatomall.service.StockpileService;
import com.example.tomatomall.util.SecurityUtil;
import com.example.tomatomall.vo.OrderVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;


@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    OrderRepository orderRepository;

    @Autowired
    StockpileRepository stockpileRepository;

    @Autowired
    CartItemRepository cartItemRepository;

    @Autowired
    CartsOrdersRelationRepository cartsOrdersRelationRepository;

    @Autowired
    CartService cartService;

    @Autowired
    SecurityUtil securityUtil;

    Map<Integer, LocalDateTime> expireMap = new HashMap<>();


    //更新订单状态
    @Override
    public String updateOrderStatus(String orderId, String alipayTradeNo, String amount) {
        Order order = orderRepository.findByOrderId(Integer.parseInt(orderId));
        expireMap.remove(Integer.parseInt(orderId));
        if(order == null) throw TomatoMallException.OrderNotExists();
        if(!order.getTotalAmount().toString().equals(amount)){
            order.setStatus(OrderStatus.FAILED);
            orderRepository.save(order);
            return "金额错误";
        }
        order.setStatus(OrderStatus.SUCCESS);
        orderRepository.save(order);
        return "支付成功";
    }

    //判断库存是否够
    @Override
    public boolean stoEnough(List<String> cartItemIds){
        List<Integer> pList = new ArrayList<>();
        for(String cartItemId: cartItemIds){
            pList.add(cartItemRepository.findByCartItemId(Integer.parseInt(cartItemId)).getProductId());
        }
        pList.sort(null);
        for(Integer productId: pList){
            ReentrantLock lock = LockConfigure.getLock(productId);
            lock.lock();
        }
        try {
            for (String cartItemId : cartItemIds) {
                CartItem cartItem = cartItemRepository.findByCartItemId(Integer.parseInt(cartItemId));
                if (cartItem == null) throw TomatoMallException.idNotMatch();
                Stockpile stockpile = stockpileRepository.findByProductId(cartItem.getProductId()).orElseThrow(TomatoMallException::idNotMatch);
                if (stockpile.getAmount() < stockpile.getFrozen() + cartItem.getQuantity()) {
                    for(Integer productId: pList){
                        ReentrantLock lock = LockConfigure.getLock(productId);
                        lock.unlock();
                    }
                    return false;
                }
            }
            for (String cartItemId : cartItemIds) {
                CartItem cartItem = cartItemRepository.findByCartItemId(Integer.parseInt(cartItemId));
                if (cartItem == null) throw TomatoMallException.idNotMatch();
                Stockpile stockpile = stockpileRepository.findByProductId(cartItem.getProductId()).orElseThrow(TomatoMallException::idNotMatch);
                stockpile.setFrozen(stockpile.getFrozen() + cartItem.getQuantity());
                stockpileRepository.save(stockpile);
            }
        }finally{
            for (Integer productId: pList){
                ReentrantLock lock = LockConfigure.getLock(productId);
                lock.unlock();
            }
        }
        return true;
    }

    //提交订单
    @Override
    public RetOrderInfo submitOrder(List<String> cartItemIds, String paymentMethod){
        if(!stoEnough(cartItemIds)) throw TomatoMallException.StoAmountNotEnough();
        Account account = securityUtil.getCurrentUser();
        Order newOrder = new Order();
        newOrder.setCreateTime(LocalDateTime.now());
        newOrder.setUserId(account.getId());
        newOrder.setStatus(OrderStatus.PENDING);
        BigDecimal totalAmount = BigDecimal.ZERO;
        Map<Integer, Integer> productIdList = new HashMap<>();
        for(String cartItemId: cartItemIds){
            totalAmount = totalAmount.add(cartService.getPrice(Integer.parseInt(cartItemId)));
            CartItem cartItem = cartItemRepository.findByCartItemId(Integer.parseInt(cartItemId));
            if(cartItem == null) throw TomatoMallException.idNotMatch();
            productIdList.put(cartItem.getProductId(), cartItem.getQuantity());
            //cartItemRepository.deleteById(Integer.parseInt(cartItemId));
        }
        newOrder.setTotalAmount(totalAmount);
        newOrder.setPaymentMethod(paymentMethod);
        orderRepository.save(newOrder);
        for(String cartItemId :cartItemIds){
            CartsOrdersRelation cartsOrdersRelation = new CartsOrdersRelation();
            cartsOrdersRelation.setOrderId(newOrder.getOrderId());
            cartsOrdersRelation.setCartItemId(Integer.parseInt(cartItemId));
            cartsOrdersRelationRepository.save(cartsOrdersRelation);
        }
        expireMap.put(newOrder.getOrderId(), LocalDateTime.now().plusMinutes(30));
        new Thread(() -> {
            try {
                Thread.sleep(30*1000*60);
                Order order = orderRepository.findById(newOrder.getOrderId()).orElseThrow(TomatoMallException::idNotMatch);
                if (order.getStatus() == OrderStatus.PENDING) {
                    expireMap.remove(newOrder.getOrderId());
                    order.setStatus(OrderStatus.TIMEOUT);
                    orderRepository.save(order);
                    for(Map.Entry<Integer, Integer> entry : productIdList.entrySet()){
                        Stockpile stockpile = stockpileRepository.findByProductId(entry.getKey()).orElseThrow(TomatoMallException::idNotMatch);
                        ReentrantLock lock = LockConfigure.getLock(entry.getKey());
                        lock.lock();
                        try{
                            stockpile.setFrozen(stockpile.getFrozen() - entry.getValue());
                            stockpileRepository.save(stockpile);
                        }finally {
                            lock.unlock();
                        }
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
        return RetOrderInfo.trans(newOrder, account.getUsername());
    }

//    @Scheduled(fixedRate = 60000)
//    @Transactional
//    public void checkAndReleaseFrozenStock(){
//        LocalDateTime thirtyMinutesAgo = LocalDateTime.now().minusMinutes(30);
//        List<Order> pendingOrders = orderRepository.findByStatusAndCreateTimeBefore(OrderStatus.PENDING, thirtyMinutesAgo);
//        for (Order order : pendingOrders) {
//            for (CartItem cartItem : ) {
//                Stockpile stockpile = stockpileRepository.findByProductId(cartItem.getProductId())
//                        .orElseThrow(TomatoMallException::idNotMatch);
//                stockpile.setFrozen(stockpile.getFrozen() - cartItem.getQuantity());
//                stockpileRepository.save(stockpile);
//            }
//            order.setStatus(OrderStatus.TIMEOUT);
//            orderRepository.save(order);
//        }
//    }

    //获取支付表单
    @Override
    public AliPayHtml startPayOrder(Integer orderId){
        Order order = orderRepository.findByOrderId(orderId);
        if(order == null) throw TomatoMallException.idNotMatch();
        AliPayHtml aliPayHtml = new AliPayHtml();
        aliPayHtml.setOrderId(orderId);
        aliPayHtml.setPaymentMethod(order.getPaymentMethod());
        aliPayHtml.setTotalAmount(order.getTotalAmount());
        AlipayClient alipayClient = new DefaultAlipayClient(
                "https://openapi-sandbox.dl.alipaydev.com/gateway.do",
                "2021000147692655",
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCos4ZIHV4KN1d+Fy5ecpiRoq3m0YoR4XqnGwEzmq6Ty+ab60PDzOmzCad/BKYJCLtxP/zZrOSldIqk9w54klKoZc33HpcZZ+z2jwPd11rm5rEN3a+s2GHBiZoS0cXpmZpW0wPrrGHs6K1zJrBpWpB2dqbKNkdxGDZbZwo3fHlqknFQfLOlVdto9bG60NWGbV77piQh8OTrMt7Ndw7rzebam33azZHGfbHOhIqbCP4v2VCS5D36yb6aeTr51ZBg2qxuSc64nBxJ/Lz9psHwYsMVqZoxJc/oGbZxDub1LZqT75Z3PB7atBGYURRCKpvuS93k2aWv8G+ppLSZ21gbmipZAgMBAAECggEAWCAnxmYo6NdOCh0b6NSeJH3BsDDHml2aD88IiqeECMrb9ZkpdhAGCLPDXpPUFCYOnLNbZ25spo3Bmzk/wvZU3YkI1c2SCwCCBa5hy7Ii1zmtRdwHWBhUwKAb7zbL1yKZQD/M7YDIStSlPuD4CKD5lBiZOkqueUK3qnmiGagZWPS7s/z+VP2ooA/ATk5G69EDXnvvcm2nUXry40T5YrhtTXfZT3fAUdWUz/mm0lCqclzbTEEai3LG2s057Ko9z+YlQvWzu+f47sRVPRn8U3aaNHf39IrNprC++Q7gl0eqimTVDzDo5y0FDlBI6Up7uk6EUHdxldVhf/ShcDhg4QLAgQKBgQDU5EIxKV3gxlOgne27wvFNZm6v42QIVo7Y9taZxmfeLFnUV/6zwApYwD5/3Ywyles1M1bV87rOLrLa/SrnFn+euF5R8N8DxAYLY/71t2NsNcilY3w0zzcHHhr+CVuelhF2WNWdJhP1dOhiORvgjvk1eecl43dEnNtOY2pFzAX+8QKBgQDK3I3Dqu+0PfcQPM4fuQBZKdd2h6EbEizAE7iJ2MLABTipHqiNkWUc6IHykooMMZVongptkH8gDqlg3NkBMpOqjh+pbNlc4RAUocof8okLT8Jarv+H7ZgNW6DIVuv8WaOYCfTf2XnrX6HNGbcIcmWQfTmB4B4YLHQz29fI6+kx6QKBgQCiS1Sut7NqjKbqFhtK/UUJVWJiUf5LYPlLK3nUBu3d8H+WonJ4Q5lfqUa8IYAkfCewCfBT8JdjYTRWP5P6USt/K1w0KWVKMKDPBC800NZJgwLwGlRwydtQYMIBEc83qX2sc/J8969VewdBAfpfiX8wJjtxpeOhedax/pXgmbWkcQKBgDbFzCUbnzL8VBv3PvRDwDtS19EyF6a2hoyqBnZ5p0OvZTgMhhgLPNDMWmHDfTCDpsKjgU9J53khXExB9PmkzUgMrbHSKPIx9mSLtoZftu7t7x0LCQWLejWJGuVcysTM8yXW8l4KWyfZH1fAbLIEKTYVCZTujVGblxh1cFLYl5MZAoGASOUFzaWeYyKW+ECygCJezGcg1dwQGNy/lQa3MAapPAonC9jUgBmKgOcNMhj1xDpIWAAg2gpNDTHjvSMUq+I0dIXDO874n2DKkzFa4eOeDrqgmqELa8y4GdJb/Pa2A0mgH8EwdinPyllnmLC3XPlZLEPHGz00ajKNnZiKk/ySz+8=",
                "json",
                "utf-8",
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsVQCLacUgjDAzUuR+YThp/oX8TUYHe4uukPqwb//fbpeXOD4EI/8WXdqXIextjREktHfhjEc7I9G2hDW4hEmW0INDbxMVYLXIlX7M/KXWwxU9kJy83lPldpFgktsPx6YtxW8HX3KHzHvhAkaAJSSufiujwss3/XStv9Z2yM5Jv2ixJFZlS9FarJAODwku2pUttq+67nwoVMnuslPYm0VDOHeBMEiP2HM/P5AyXgj13XhYh/f4e4j43/ROVt04DfxIq0Xl0oXAYuZhODgXbUw5dVD+9kchH0oGu7UgHJiofovlVPOG9/+OmMqQZSDBQhzIzjweB+GI/lZxMXzqcwubwIDAQAB",
                "RSA2"
        );
        AlipayTradePagePayRequest request = new AlipayTradePagePayRequest();
        request.setNotifyUrl("https://0ce0-121-236-217-188.ngrok-free.app/api/orders/notify");
        AlipayTradePagePayModel model = new AlipayTradePagePayModel();
        String outTradeNo = orderId.toString();
        String totalAmount = order.getTotalAmount().setScale(2, BigDecimal.ROUND_HALF_UP).toString(); // 金额（元，精确到分）
        String subject = "112233";////

        model.setOutTradeNo(outTradeNo);
        model.setTotalAmount(totalAmount);
        model.setSubject(subject);
        model.setProductCode("FAST_INSTANT_TRADE_PAY");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        model.setTimeExpire(expireMap.get(orderId).format(formatter));
        request.setBizModel(model);
        String paymentForm;
        AlipayTradePagePayResponse response;
        try {
            response = alipayClient.pageExecute(request, "POST");
            paymentForm = response.getBody();
        } catch (AlipayApiException e) {
            throw new RuntimeException("生成支付宝支付表单失败", e);
        }
        if (response.isSuccess()) {
            System.out.println("调用成功");
        } else {
            System.out.println("调用失败");
        }
        aliPayHtml.setPaymentForm(paymentForm);
        return aliPayHtml;
    }
}

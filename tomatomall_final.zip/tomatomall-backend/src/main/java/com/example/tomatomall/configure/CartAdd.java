package com.example.tomatomall.configure;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CartAdd {
    private String productId;

    private Integer quantity;
}

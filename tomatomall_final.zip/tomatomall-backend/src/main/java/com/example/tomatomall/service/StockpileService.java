package com.example.tomatomall.service;

import com.example.tomatomall.vo.StockpileVO;

public interface StockpileService {

    String updateStockpile(Integer productId, Integer amount);

    StockpileVO getStockpile(Integer productId);

    void reduceStock(String orderId);

}

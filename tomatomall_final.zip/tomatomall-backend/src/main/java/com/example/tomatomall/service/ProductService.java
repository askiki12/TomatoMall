package com.example.tomatomall.service;

import com.example.tomatomall.vo.ProductVO;

import java.util.List;

public interface ProductService {
    List<ProductVO> getAllProducts();

    ProductVO getTheProduct(Integer id);

    String updateProductInfo(ProductVO productVO);

    ProductVO addProduct(ProductVO productVO);

    String deleteProduct(Integer id);
}

package com.example.tomatomall.vo;


import com.example.tomatomall.po.Specification;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SpecificationVO {

    private Integer id;

    private String item;

    private String value;

    private Integer productId;

    public Specification toPO() {
        Specification specification = new Specification();
        specification.setId(this.id);
        specification.setItem(this.item);
        specification.setValue(this.value);
        specification.setProductId(this.productId);
        return specification;
    }
}

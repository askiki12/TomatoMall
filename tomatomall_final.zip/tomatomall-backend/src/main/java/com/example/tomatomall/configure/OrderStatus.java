package com.example.tomatomall.configure;

public enum OrderStatus {
    PENDING, SUCCESS, FAILED, TIMEOUT
}
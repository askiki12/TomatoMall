package com.example.tomatomall.service.serviceImpl;

import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.Account;
import com.example.tomatomall.repository.AccountRepository;
import com.example.tomatomall.service.AccountService;
import com.example.tomatomall.util.SecurityUtil;
import com.example.tomatomall.util.TokenUtil;
import com.example.tomatomall.vo.AccountVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {
    @Autowired
    AccountRepository accountRepository;

    @Autowired
    TokenUtil tokenUtil;

    @Autowired
    SecurityUtil securityUtil;

    @Autowired
    PasswordEncoder passwordEncoder;

    //根据用户名获取用户
    @Override
    public AccountVO getByUsername(String Username){
        Account account = accountRepository.findByUsername(Username);
        if(account == null) throw TomatoMallException.accountNotExists();
        return account.toVO();
    }

    //注册
    @Override
    public String create(AccountVO accountVO){
        Account account = accountRepository.findByUsername(accountVO.getUsername());
        if(account != null) throw TomatoMallException.accountAlreadyExists();
        Account newaccount = accountVO.toPO();
        String rawPassword = accountVO.getPassword();
        newaccount.setPassword(passwordEncoder.encode(rawPassword));
        accountRepository.save(newaccount);
        return "注册成功";
    }

    //登录
    @Override
    public String login(String username, String password){
        Account account = accountRepository.findByUsername(username);
        if(account == null) throw TomatoMallException.usernameOrPasswordError();
        if(!passwordEncoder.matches(password, account.getPassword())) throw TomatoMallException.usernameOrPasswordError();
        return tokenUtil.getToken(account);
    }

    //更新用户信息
    @Override
    public String updateInformation(AccountVO accountVO){
        Account account = securityUtil.getCurrentUser();
        if(!accountVO.getUsername().equals(account.getUsername())) throw TomatoMallException.accountNameCantChange();
        if(accountVO.getTelephone() != null) account.setTelephone(accountVO.getTelephone());
        if(accountVO.getEmail() != null) account.setEmail(accountVO.getEmail());
        if(accountVO.getAvatar() != null) account.setAvatar(accountVO.getAvatar());
        if(accountVO.getName() != null) account.setName(accountVO.getName());
        if(accountVO.getLocation() != null) account.setLocation(accountVO.getLocation());
        if(accountVO.getPassword() != null) {
            String newPassword = passwordEncoder.encode(accountVO.getPassword());
            account.setPassword(newPassword);
        }
        accountRepository.save(account);
        return "更新成功";
    }

    //获取当前用户
    @Override
    public AccountVO getCurrentUser(){
        return securityUtil.getCurrentUser().toVO();
    }

    //获取对应id的用户名
    @Override
    public String getUsernameById(Integer id){
        Account account = accountRepository.findById(id).orElseThrow(TomatoMallException::accountNotExists);
        return account.getUsername();
    }
}

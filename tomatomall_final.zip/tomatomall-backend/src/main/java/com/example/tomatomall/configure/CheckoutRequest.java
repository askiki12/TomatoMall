package com.example.tomatomall.configure;

import lombok.Getter;

import java.util.List;

@Getter
public class CheckoutRequest {
    private List<String> cartItemIds;
    private ShippingAddress shippingAddress;
    private String paymentMethod;
    // 省略 getter/setter
}

package com.example.tomatomall.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TomatoMallException extends RuntimeException{

    private String errorCode;

    public TomatoMallException(String message) {
        super(message);
        this.errorCode = "400";
    }

    public TomatoMallException(String message, String error){
        super(message);
        errorCode = error;
    }

    public static TomatoMallException accountAlreadyExists(){
        return new TomatoMallException("用户名已存在");
    }

    public static TomatoMallException notLogin(){
        return new TomatoMallException("未登录!", "401");
    }

    public static TomatoMallException usernameOrPasswordError(){
        return new TomatoMallException("用户不存在/用户密码错误");
    }

    public static TomatoMallException fileUploadFail(){
        return new TomatoMallException("文件上传失败!");
    }


    public static TomatoMallException accountNotExists(){
        return new TomatoMallException("用户不存在!");
    }

    public static TomatoMallException accountNameCantChange(){
        return new TomatoMallException("用户名不可修改");
    }

    public static TomatoMallException productNotExists(){
        return new TomatoMallException("商品不存在!");
    }

    public static TomatoMallException idNotMatch(){
        return new TomatoMallException("商品id不匹配!");
    }

    public static TomatoMallException productAlreadyExists(){
        return new TomatoMallException("商品已存在!");
    }

    public static TomatoMallException CartItemNotExists(){
        return new TomatoMallException("购物车商品不存在");
    }

    public static TomatoMallException StoAmountNotEnough(){
        return new TomatoMallException("购物车库存不足");
    }

    public static TomatoMallException OrderNotExists(){
        return new TomatoMallException("订单不存在");
    }

    public static TomatoMallException AdvertisementNotExists(){
        return new TomatoMallException("广告不存在");
    }

    public static TomatoMallException NoContent(){return new TomatoMallException("无评论内容");}

    public static TomatoMallException CommentNotExists(){
        return new TomatoMallException("评论不存在");
    }

    public static TomatoMallException MarkAlreadyExists(){
        return new TomatoMallException("您已经评分");
    }

    public static TomatoMallException MarkNotExists(){
        return new TomatoMallException("您评分不存在");
    }

}

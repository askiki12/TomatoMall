package com.example.tomatomall.exception;

import com.example.tomatomall.vo.Response;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(value = TomatoMallException.class)
    public Response<String> handleAIExternalException(TomatoMallException e) {
        //e.printStackTrace();
        System.out.println(e.getMessage());
        System.out.println(e.getErrorCode());
        return Response.buildFailure(e.getMessage(),e.getErrorCode());
    }
}

package com.example.tomatomall.service;
import com.example.tomatomall.vo.AccountVO;

public interface AccountService {
    AccountVO getByUsername(String Username);

    String create(AccountVO accountVO);

    String login(String username, String password);

    String updateInformation(AccountVO accountVO);

    AccountVO getCurrentUser();

    String getUsernameById(Integer id);
}

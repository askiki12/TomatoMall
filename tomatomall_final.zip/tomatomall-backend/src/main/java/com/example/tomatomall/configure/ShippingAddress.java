package com.example.tomatomall.configure;

public class ShippingAddress {
    String name;
    String phone;
    String postcode;
    String address;
}

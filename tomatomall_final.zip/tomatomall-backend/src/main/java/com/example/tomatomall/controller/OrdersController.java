package com.example.tomatomall.controller;

import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.AlipaySignature;
import com.example.tomatomall.configure.AliPayHtml;
import com.example.tomatomall.repository.OrderRepository;
import com.example.tomatomall.service.OrderService;
import com.example.tomatomall.service.StockpileService;
import com.example.tomatomall.vo.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/orders")
public class OrdersController {
    static String ALIPAY_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsVQCLacUgjDAzUuR+YThp/oX8TUYHe4uukPqwb//fbpeXOD4EI/8WXdqXIextjREktHfhjEc7I9G2hDW4hEmW0INDbxMVYLXIlX7M/KXWwxU9kJy83lPldpFgktsPx6YtxW8HX3KHzHvhAkaAJSSufiujwss3/XStv9Z2yM5Jv2ixJFZlS9FarJAODwku2pUttq+67nwoVMnuslPYm0VDOHeBMEiP2HM/P5AyXgj13XhYh/f4e4j43/ROVt04DfxIq0Xl0oXAYuZhODgXbUw5dVD+9kchH0oGu7UgHJiofovlVPOG9/+OmMqQZSDBQhzIzjweB+GI/lZxMXzqcwubwIDAQAB\n";

    @Autowired
    OrderService orderService;

    @Autowired
    StockpileService stockpileService;

    @Autowired
    OrderRepository orderRepository;

    @PostMapping("/notify")
    public void handleAlipayNotify(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("ssssss");

        // 1. 解析支付宝回调参数（通常是 application/x-www-form-urlencoded）
        Map<String, String> params = request.getParameterMap().entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue()[0]));

        // 2. 验证支付宝签名（防止伪造请求）
        boolean signVerified = false;
        try {
            signVerified = AlipaySignature.rsaCheckV1(params, ALIPAY_PUBLIC_KEY, "UTF-8", "RSA2");
        } catch (AlipayApiException e) {
            throw new RuntimeException(e);
        }
        if (!signVerified) {
            response.getWriter().print("fail");
            return;
        }

        // 3. 处理业务逻辑（更新订单、减库存等）
        String tradeStatus = params.get("trade_status");
        if ("TRADE_SUCCESS".equals(tradeStatus)) {
            String orderId = params.get("out_trade_no"); // 您的订单号
            String alipayTradeNo = params.get("trade_no"); // 支付宝交易号
            String amount = params.get("total_amount"); // 支付金额

            // 更新订单状态（注意幂等性，防止重复处理）
            orderService.updateOrderStatus(orderId, alipayTradeNo, amount);

            // 扣减库存（建议加锁或乐观锁）
            stockpileService.reduceStock(orderId);
        }

        response.getWriter().print("success");
    }

    @PostMapping("{orderId}/pay")
    public Response<AliPayHtml> startPayOrder(@PathVariable Integer orderId){
        return Response.buildSuccess(orderService.startPayOrder(orderId));
    }

    @GetMapping("/status/{orderId}")
    public Response<String> getOrderStatus(@PathVariable Integer orderId){
        return Response.buildSuccess(orderRepository.findByOrderId(orderId).getStatus().name());
    }
}

package com.example.tomatomall.service;

import com.example.tomatomall.vo.CommentVO;

import java.util.List;

public interface CommentSetvice {

    List<CommentVO> getByProductId(Integer productId);

    String createComment(Integer productId, String content);

    String deleteComment(Integer id);

}

package com.example.tomatomall.configure;

import com.example.tomatomall.po.Order;
import com.example.tomatomall.service.AccountService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RetOrderInfo {
    @Autowired
    AccountService accountService;

    private Integer orderId;

    private String username;

    private BigDecimal totalAmount;

    private String paymentMethod;

    private OrderStatus status = OrderStatus.PENDING;

    private LocalDateTime createTime;

    public static RetOrderInfo trans(Order order, String username){
        RetOrderInfo retOrderInfo = new RetOrderInfo();
        retOrderInfo.setOrderId(order.getOrderId());
        retOrderInfo.setStatus(order.getStatus());
        retOrderInfo.setTotalAmount(order.getTotalAmount());
        retOrderInfo.setPaymentMethod(order.getPaymentMethod());
        retOrderInfo.setCreateTime(order.getCreateTime());
        retOrderInfo.setUsername(username);
        return retOrderInfo;
    }
}

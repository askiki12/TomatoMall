package com.example.tomatomall.vo;

import com.example.tomatomall.po.CartsOrdersRelation;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CartsOrdersRelationVO {

    private Integer id;

    private Integer cartItemId;

    private Integer orderId;

    public CartsOrdersRelation toPO(){
        CartsOrdersRelation cartsOrdersRelation = new CartsOrdersRelation();
        cartsOrdersRelation.setId(this.id);
        cartsOrdersRelation.setCartItemId(this.cartItemId);
        cartsOrdersRelation.setOrderId(this.orderId);
        return cartsOrdersRelation;
    }
}

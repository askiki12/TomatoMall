package com.example.tomatomall.controller;


import com.example.tomatomall.service.AdvertisementService;
import com.example.tomatomall.vo.AdvertisementVO;
import com.example.tomatomall.vo.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/advertisements")
public class AdvertisementController {

    @Autowired
    AdvertisementService advertisementService;

    @GetMapping
    public Response<List<AdvertisementVO>> getAllAdvertisement(){
        return Response.buildSuccess(advertisementService.getAllAdvertisement());
    }

    @PutMapping
    public Response<String> updateTheAdvertisement(@RequestBody AdvertisementVO advertisementVO){
        return Response.buildSuccess(advertisementService.updateAdvertisement(advertisementVO));
    }

    @PostMapping
    public Response<AdvertisementVO> createAdvertisement(@RequestBody AdvertisementVO advertisementVO){
        return Response.buildSuccess(advertisementService.createAdvertisement(advertisementVO));
    }

    @DeleteMapping("/{id}")
    public Response<String> deleteAdvertisement(@PathVariable Integer id){
        return Response.buildSuccess(advertisementService.deleteAdvertisement(id));
    }

}

package com.example.tomatomall.service.serviceImpl;

import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.Advertisement;
import com.example.tomatomall.po.Product;
import com.example.tomatomall.repository.AdvertisementRepository;
import com.example.tomatomall.repository.ProductRepository;
import com.example.tomatomall.service.AdvertisementService;
import com.example.tomatomall.vo.AdvertisementVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AdvertisementServiceImpl implements AdvertisementService {

    @Autowired
    AdvertisementRepository advertisementRepository;

    @Autowired
    ProductRepository productRepository;

    //创建广告
    @Override
    public AdvertisementVO createAdvertisement(AdvertisementVO advertisementVO){
        Integer productId = advertisementVO.getProductId();
        Product product = productRepository.findById(productId).orElseThrow(TomatoMallException::productNotExists);
        Advertisement advertisement = advertisementVO.toPO();
        advertisement.setProduct(product);
        advertisementRepository.save(advertisement);
        advertisementVO = advertisement.toVO();
        return advertisementVO;
    }

    //获取广告
    @Override
    public List<AdvertisementVO> getAllAdvertisement(){
        return advertisementRepository.findAll().stream()
                .map(Advertisement::toVO)
                .collect(Collectors.toList());
    }

    //更新广告
    @Override
    public String updateAdvertisement(AdvertisementVO advertisementVO){
        Advertisement advertisement = advertisementRepository.findById(advertisementVO.getId()).orElseThrow(TomatoMallException::AdvertisementNotExists);
        advertisement.setProductId(advertisementVO.getProductId());
        advertisement.setProduct(productRepository.findById(advertisementVO.getProductId()).orElseThrow(TomatoMallException::productNotExists));
        if(advertisementVO.getContent() != null) advertisement.setContent(advertisementVO.getContent());
        if(advertisementVO.getTitle() != null) advertisement.setTitle(advertisementVO.getTitle());
        if(advertisementVO.getImgUrl() != null) advertisement.setImgUrl(advertisementVO.getImgUrl());
        advertisementRepository.save(advertisement);
        return "更新成功";
    }

    //删除广告
    @Override
    public String deleteAdvertisement(Integer id){
        Advertisement advertisement = advertisementRepository.findById(id).orElseThrow(TomatoMallException::AdvertisementNotExists);
        advertisementRepository.delete(advertisement);
        return "删除成功";
    }

}

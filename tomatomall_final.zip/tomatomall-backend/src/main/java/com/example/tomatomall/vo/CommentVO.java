package com.example.tomatomall.vo;

import com.example.tomatomall.po.Comment;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class CommentVO {

    private Integer id;

    private Integer productId;

    private Integer userId;

    private String content;

    private LocalDateTime time;

    public Comment toPO(){
        Comment comment = new Comment();
        comment.setId(id);
        comment.setUserId(userId);
        comment.setProductId(productId);
        comment.setContent(content);
        comment.setTime(time);
        return comment;
    }


}

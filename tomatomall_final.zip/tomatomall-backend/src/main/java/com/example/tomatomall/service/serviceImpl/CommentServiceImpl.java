package com.example.tomatomall.service.serviceImpl;

import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.Account;
import com.example.tomatomall.po.Comment;
import com.example.tomatomall.po.Product;
import com.example.tomatomall.repository.CommentRepository;
import com.example.tomatomall.repository.ProductRepository;
import com.example.tomatomall.service.CommentSetvice;
import com.example.tomatomall.util.SecurityUtil;
import com.example.tomatomall.vo.CommentVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentServiceImpl implements CommentSetvice {

    @Autowired
    CommentRepository commentRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    SecurityUtil securityUtil;

    //获取评论
    @Override
    public List<CommentVO> getByProductId(Integer productId) {
        productRepository.findById(productId).orElseThrow(TomatoMallException::productNotExists);
        return commentRepository.findByProductId(productId).stream().map(Comment::toVO).collect(Collectors.toList());

    }

    //创建评论
    @Override
    public String createComment(Integer productId, String content) {
        Account account = securityUtil.getCurrentUser();
        Product product = productRepository.findById(productId).orElseThrow(TomatoMallException::productNotExists);
        if(content.isEmpty()) throw TomatoMallException.NoContent();
        Comment comment = new Comment();
        comment.setContent(content);
        comment.setProductId(productId);
        comment.setUserId(account.getId());
        comment.setTime(LocalDateTime.now());
        commentRepository.save(comment);
        return "发布成功";
    }

    //删除评论
    @Override
    public String deleteComment(Integer id) {
        Comment comment = commentRepository.findById(id).orElseThrow(TomatoMallException::CommentNotExists);
        commentRepository.delete(comment);
        return "删除成功";
    }
}

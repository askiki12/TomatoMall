package com.example.tomatomall.controller;

import com.example.tomatomall.configure.MarkRequest;
import com.example.tomatomall.service.MarkService;
import com.example.tomatomall.vo.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/marks")
public class MarkController {

    @Autowired
    MarkService markService;

    @GetMapping("/{productId}")
    public Response<String> getProductMark(@PathVariable Integer productId){
        return Response.buildSuccess(markService.getMyProductMark(productId));
    }

    @PostMapping("/create")
    public Response<String> createProductMark(@RequestBody MarkRequest markRequest){
        return Response.buildSuccess(markService.createMark(markRequest.getProductId(),markRequest.getMarkStar()));
    }

    @PostMapping("/change")
    public Response<String> changeProductMark(@RequestBody MarkRequest markRequest){
        return Response.buildSuccess(markService.changeMark(markRequest.getProductId(),markRequest.getMarkStar()));
    }

    @DeleteMapping("/{productId}")
    public Response<String> deleteMark(@PathVariable Integer productId){
        return Response.buildSuccess(markService.deleteMark(productId));
    }

}

package com.example.tomatomall.repository;

import com.example.tomatomall.configure.OrderStatus;
import com.example.tomatomall.po.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Integer> {
    public Order findByOrderId(Integer orderId);

    public List<Order> findByStatusAndCreateTimeBefore(OrderStatus orderStatus, LocalDateTime localDateTime);
}

package com.example.tomatomall.configure;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class AliPayHtml {
    String paymentForm;
    Integer orderId;
    BigDecimal totalAmount;
    String paymentMethod;
}

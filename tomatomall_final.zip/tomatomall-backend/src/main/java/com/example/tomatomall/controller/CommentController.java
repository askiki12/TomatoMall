package com.example.tomatomall.controller;

import com.example.tomatomall.configure.CommentRequest;
import com.example.tomatomall.repository.CommentRepository;
import com.example.tomatomall.service.CommentSetvice;
import com.example.tomatomall.vo.CommentVO;
import com.example.tomatomall.vo.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

@RestController
@RequestMapping("/api/comments")
public class CommentController {

    @Autowired
    CommentSetvice commentSetvice;

        @GetMapping("/{productId}")
        public Response<List<CommentVO>> getByProductId(@PathVariable Integer productId){
            return Response.buildSuccess(commentSetvice.getByProductId(productId));
        }

        @PostMapping("/create")
        public Response<String> createComment(@RequestBody CommentRequest commentRequest){
            return Response.buildSuccess(commentSetvice.createComment(commentRequest.getProductId(), commentRequest.getContent()));
        }

        @DeleteMapping("/{commentId}")
        public Response<String> deleteComment(@PathVariable Integer commentId){
            return Response.buildSuccess(commentSetvice.deleteComment(commentId));
        }

}

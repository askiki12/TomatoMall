package com.example.tomatomall.service;

import com.example.tomatomall.configure.AliPayHtml;
import com.example.tomatomall.configure.RetOrderInfo;
import com.example.tomatomall.vo.OrderVO;

import java.util.List;

public interface OrderService {

    String updateOrderStatus(String orderId, String alipayTradeNo, String amount);

    RetOrderInfo submitOrder(List<String> cartItemIds, String paymentMethod);

    AliPayHtml startPayOrder(Integer orderId);

    boolean stoEnough(List<String> cartItemIds);

}

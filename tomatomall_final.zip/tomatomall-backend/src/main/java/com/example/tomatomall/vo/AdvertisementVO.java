package com.example.tomatomall.vo;


import com.example.tomatomall.po.Advertisement;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AdvertisementVO {

    private Integer id;

    private String title;

    private String content;

    private String imgUrl;

    private Integer productId;

    public Advertisement toPO(){
        Advertisement advertisement = new Advertisement();
        advertisement.setId(this.id);
        advertisement.setTitle(this.title);
        advertisement.setContent(this.content);
        advertisement.setProductId(this.productId);
        advertisement.setImgUrl(this.imgUrl);
        return advertisement;
    }
}

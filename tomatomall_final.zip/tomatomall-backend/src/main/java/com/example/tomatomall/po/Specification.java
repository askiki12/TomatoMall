package com.example.tomatomall.po;
import com.example.tomatomall.vo.SpecificationVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "specifications")
public class Specification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 50)
    private String item;

    @Column(nullable = false, length = 255)
    private String value;

    @Column(nullable = false, name = "product_id")
    private Integer productId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private Product product;

    public SpecificationVO toVO(){
        SpecificationVO specificationVO = new SpecificationVO();
        specificationVO.setId(this.id);
        specificationVO.setItem(this.item);
        specificationVO.setValue(this.value);
        specificationVO.setProductId(this.productId);
        return specificationVO;
    }
}

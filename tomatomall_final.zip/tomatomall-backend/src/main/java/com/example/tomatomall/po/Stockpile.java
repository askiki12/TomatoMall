package com.example.tomatomall.po;
import com.example.tomatomall.vo.StockpileVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "stockpiles")
public class Stockpile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, name = "product_id")
    private Integer productId;

    @Column(nullable = false)
    private Integer amount;//商家总库存

    @Column(nullable = false)
    private Integer frozen;//提交订单锁

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private Product product;

    public StockpileVO toVO(){
        StockpileVO stockpileVO = new StockpileVO();
        stockpileVO.setId(this.id);
        stockpileVO.setFrozen(this.frozen);
        stockpileVO.setAmount(this.amount);
        stockpileVO.setProductId(this.productId);
        return stockpileVO;
    }
}

package com.example.tomatomall.vo;

import com.example.tomatomall.po.CartItem;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CartItemVO {

    private Integer cartItemId;

    private Integer userId;

    private Integer productId;

    private Integer quantity = 1;


    public CartItem toPO(){
        CartItem cartItem = new CartItem();
        cartItem.setCartItemId(this.cartItemId);
        cartItem.setUserId(this.userId);
        cartItem.setProductId(this.productId);
        cartItem.setQuantity(this.quantity);
        return cartItem;
    }
}

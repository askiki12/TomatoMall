package com.example.tomatomall.po;

import com.example.tomatomall.vo.CommentVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "comments")
public class Comment {//getByProductId  return list；   setByProductIdAndUserId；  deleteById
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "product_id")
    private Integer productId;

    @Column(name = "userId")
    private Integer userId;

    @ManyToOne
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private Product product;

    @ManyToOne
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    private Account user;

    @Column(name = "content")
    private String content;

    @Column(name = "time")
    private LocalDateTime time;


    public CommentVO toVO(){
        CommentVO commentVO = new CommentVO();
        commentVO.setId(id);
        commentVO.setProductId(productId);
        commentVO.setUserId(userId);
        commentVO.setContent(content);
        commentVO.setTime(time);
        return commentVO;
    }



}

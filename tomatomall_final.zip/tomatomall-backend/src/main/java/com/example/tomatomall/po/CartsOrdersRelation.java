package com.example.tomatomall.po;

import com.example.tomatomall.vo.CartsOrdersRelationVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "carts_orders_relation")
public class CartsOrdersRelation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "cart_item_id")
    private Integer cartItemId;

    @Column(name = "order_id")
    private Integer orderId;

    @ManyToOne
    @JoinColumn(name = "cart_item_id", insertable = false, updatable = false)
    private CartItem cartItem;

    @ManyToOne
    @JoinColumn(name = "order_id", insertable = false, updatable = false)
    private Order order;

    public CartsOrdersRelationVO toVO(){
        CartsOrdersRelationVO cartsOrdersRelationVO = new CartsOrdersRelationVO();
        cartsOrdersRelationVO.setCartItemId(this.cartItemId);
        cartsOrdersRelationVO.setOrderId(this.orderId);
        cartsOrdersRelationVO.setId(this.id);
        return cartsOrdersRelationVO;
    }
}

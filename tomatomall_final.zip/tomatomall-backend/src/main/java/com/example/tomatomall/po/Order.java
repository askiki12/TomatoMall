package com.example.tomatomall.po;

import com.example.tomatomall.configure.OrderStatus;
import com.example.tomatomall.vo.OrderVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "order_id")
    private Integer orderId;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "total_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalAmount;

    @Column(name = "payment_method", nullable = false)
    private String paymentMethod;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private OrderStatus status = OrderStatus.PENDING;

    @Column(name = "create_time", updatable = false)
    private LocalDateTime createTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private Account user;

    public OrderVO toVO(){
        OrderVO orderVO = new OrderVO();
        orderVO.setOrderId(this.orderId);
        orderVO.setUserId(this.userId);
        orderVO.setTotalAmount(this.totalAmount);
        orderVO.setPaymentMethod(this.paymentMethod);
        orderVO.setCreateTime(this.createTime);
        orderVO.setStatus(this.status);
        return orderVO;
    }
}

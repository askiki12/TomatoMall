package com.example.tomatomall.vo;

import com.example.tomatomall.configure.OrderStatus;
import com.example.tomatomall.po.Order;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class OrderVO {

    private Integer orderId;

    private Integer userId;

    private BigDecimal totalAmount;

    private String paymentMethod;

    private OrderStatus status = OrderStatus.PENDING;

    private LocalDateTime createTime;

    public Order toPO(){
        Order order = new Order();
        order.setOrderId(this.orderId);
        order.setUserId(this.userId);
        order.setTotalAmount(this.totalAmount);
        order.setPaymentMethod(this.paymentMethod);
        order.setStatus(this.status);
        order.setCreateTime(this.createTime);
        return order;
    }
}

package com.example.tomatomall.repository;

import com.example.tomatomall.po.Mark;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MarkRepository extends JpaRepository<Mark, Integer> {
    List<Mark> findByProductId(Integer productId);
    Mark findByProductIdAndUserId(Integer productId, Integer userId);
    void deleteByProductIdAndUserId(Integer productId, Integer userId);
}

package com.example.tomatomall.configure;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockConfigure {

    public static Lock stockLock = new ReentrantLock();
    private static final ConcurrentHashMap<Integer, ReentrantLock> lockMap = new ConcurrentHashMap<>();
    public static ReentrantLock getLock(Integer itemId) {
        return lockMap.computeIfAbsent(itemId, k -> new ReentrantLock());
    }
}

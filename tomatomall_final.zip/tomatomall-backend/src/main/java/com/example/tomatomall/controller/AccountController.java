package com.example.tomatomall.controller;

import com.example.tomatomall.configure.LoginRequest;
import com.example.tomatomall.service.AccountService;
import com.example.tomatomall.vo.AccountVO;
import com.example.tomatomall.vo.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    AccountService accountService;

    @GetMapping("/{username}")
    public Response<AccountVO> getUser(@PathVariable String username) {
        return Response.buildSuccess(accountService.getByUsername(username));
    }

    @PostMapping
    public Response<String> createUser(@RequestBody AccountVO accountVO) {
        return Response.buildSuccess(accountService.create(accountVO));
    }

    @PutMapping
    public Response<String> updateUser(@RequestBody AccountVO accountVO) {
        return Response.buildSuccess(accountService.updateInformation(accountVO));
    }

    //登录
    @PostMapping("/login")
    public Response<String> login(@RequestBody LoginRequest loginRequest) {
        String username = loginRequest.getUsername();
        String password = loginRequest.getPassword();
        return Response.buildSuccess(accountService.login(username, password));
    }

    @GetMapping("")
    public Response<AccountVO> getCurrentUser(){
        return Response.buildSuccess(accountService.getCurrentUser());
    }

    @GetMapping("/name/{id}")
    public Response<String> getUsernameById(@PathVariable Integer id){
        return Response.buildSuccess(accountService.getUsernameById(id));
    }
}

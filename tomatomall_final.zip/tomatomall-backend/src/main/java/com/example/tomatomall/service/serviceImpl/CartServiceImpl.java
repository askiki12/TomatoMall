package com.example.tomatomall.service.serviceImpl;

import com.example.tomatomall.configure.CartShow;
import com.example.tomatomall.configure.LockConfigure;
import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.*;
import com.example.tomatomall.repository.CartItemRepository;
import com.example.tomatomall.repository.CartsOrdersRelationRepository;
import com.example.tomatomall.repository.ProductRepository;
import com.example.tomatomall.repository.StockpileRepository;
import com.example.tomatomall.service.CartService;
import com.example.tomatomall.util.SecurityUtil;
import com.example.tomatomall.vo.CartItemVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;


@Service
public class CartServiceImpl implements CartService {

    @Autowired
    CartItemRepository cartItemRepository;

    @Autowired
    StockpileRepository stockpileRepository;

    @Autowired
    CartsOrdersRelationRepository cartsOrdersRelationRepository;

    @Autowired
    SecurityUtil securityUtil;

    @Autowired
    ProductRepository productRepository;



    //加入购物车
    @Override
    public CartShow addCartItem(Integer productId, Integer quantity){
        Product product = productRepository.findById(productId).orElse(null);
        if(product == null) throw TomatoMallException.productNotExists();
        Account account = securityUtil.getCurrentUser();
        Integer userId = account.getId();
        CartItem cartItem = cartItemRepository.findByProductIdAndUserId(productId, userId);
        //lock
        ReentrantLock lock = LockConfigure.getLock(productId);
        lock.lock();
        try {
            Stockpile stockpile = stockpileRepository.findByProductId(productId).orElseThrow(TomatoMallException::productNotExists);
            Integer stoNum = stockpile.getAmount();
            Integer froNum = stockpile.getFrozen();
            if (cartItem != null) {
                Integer oldQuantity = cartItem.getQuantity();
                if (oldQuantity + quantity > stoNum-froNum) {
                    throw TomatoMallException.StoAmountNotEnough();
                }
                cartItem.setQuantity(oldQuantity + quantity);
                cartItemRepository.save(cartItem);
            } else {
                cartItem = new CartItem();
                if (quantity > stoNum-froNum) throw TomatoMallException.StoAmountNotEnough();
                cartItem.setQuantity(quantity);
                cartItem.setAccount(account);
                cartItem.setUserId(account.getId());
                cartItem.setProduct(product);
                cartItem.setProductId(productId);
                cartItemRepository.save(cartItem);
            }
        }finally {
            lock.unlock();
        }
        CartShow cartShow = new CartShow();
        cartShow.setDescription(product.getDescription());
        cartShow.setDetail(product.getDetail());
        cartShow.setPrice(product.getPrice());
        cartShow.setCover(product.getCover());
        cartShow.setTitle(product.getTitle());
        cartShow.setQuantity(quantity);
        cartShow.setCartItemId(cartItem.getCartItemId().toString());
        cartShow.setProductId(productId.toString());
        return cartShow;
    }

    //删除购物车
    @Override
    public String deleteCartItem(Integer cartItemId){
        CartItem cartItem = cartItemRepository.findById(cartItemId).orElse(null);
        if(cartItem == null) throw TomatoMallException.CartItemNotExists();
        List<CartsOrdersRelation> cartsOrdersRelations = cartsOrdersRelationRepository.findByCartItemId(cartItemId);
        cartsOrdersRelationRepository.deleteAll(cartsOrdersRelations);
        cartItemRepository.delete(cartItem);
        return "删除成功";
    }

    //改变购物车商品数目
    @Override
    public String changeProductInCartNum(Integer cartItemId, Integer quantity){
        CartItem cartItem = cartItemRepository.findById(cartItemId).orElse(null);
        if(cartItem == null) throw TomatoMallException.CartItemNotExists();
        Integer productId = cartItem.getProductId();
        Stockpile stockpile = stockpileRepository.findByProductId(productId).orElseThrow(TomatoMallException::productNotExists);
        Integer stoNum = stockpile.getAmount();
        Integer froNum = stockpile.getFrozen();
        ReentrantLock lock = LockConfigure.getLock(productId);
        lock.lock();
        try {
            if (quantity > stoNum - froNum) throw TomatoMallException.StoAmountNotEnough();
            cartItem.setQuantity(quantity);
            cartItemRepository.save(cartItem);
        }finally {
            lock.unlock();
        }
        return "修改数量成功";
    }

    //获取购物车列表
    @Override
    public List<CartShow> getCartList(){
        Account account = securityUtil.getCurrentUser();
        Integer userId = account.getId();
        List<CartItem> cartItems = cartItemRepository.findByUserId(userId);
        List<CartShow> cartList = new ArrayList<>();
        for(CartItem cartItem: cartItems){
            CartShow cartShow = new CartShow();
            Product product = cartItem.getProduct();
            cartShow.setDescription(product.getDescription());
            cartShow.setDetail(product.getDetail());
            cartShow.setPrice(product.getPrice());
            cartShow.setCover(product.getCover());
            cartShow.setTitle(product.getTitle());
            cartShow.setProductId(product.getId().toString());
            cartShow.setQuantity(cartItem.getQuantity());
            cartShow.setCartItemId(cartItem.getCartItemId().toString());
            cartList.add(cartShow);
        }
        return cartList;
    }

    //获取选中购物车价格
    @Override
    public BigDecimal getPrice(Integer id){
        CartItem cartItem = cartItemRepository.findById(id).orElse(null);
        if(cartItem == null) throw TomatoMallException.idNotMatch();
        Product product = productRepository.findById(cartItem.getProductId()).orElse(null);
        if(product == null) throw TomatoMallException.idNotMatch();
        BigDecimal price = product.getPrice();
        BigDecimal quantity = new BigDecimal(cartItem.getQuantity());
        return quantity.multiply(price);
    }
}

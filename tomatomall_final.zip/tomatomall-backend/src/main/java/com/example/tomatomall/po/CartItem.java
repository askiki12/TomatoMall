package com.example.tomatomall.po;

import com.example.tomatomall.vo.CartItemVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "carts")
public class CartItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cart_item_id")
    private Integer cartItemId;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "product_id")
    private Integer productId;

    @Column(nullable = false)
    private Integer quantity = 1;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private Account account;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private Product product;

    public CartItemVO toVO(){
        CartItemVO cartItemVO = new CartItemVO();
        cartItemVO.setCartItemId(this.cartItemId);
        cartItemVO.setUserId(this.userId);
        cartItemVO.setProductId(this.productId);
        cartItemVO.setQuantity(this.quantity);
        return cartItemVO;
    }

}

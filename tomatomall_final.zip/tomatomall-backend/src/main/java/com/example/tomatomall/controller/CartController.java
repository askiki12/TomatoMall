package com.example.tomatomall.controller;


import com.example.tomatomall.configure.*;
import com.example.tomatomall.service.CartService;
import com.example.tomatomall.service.OrderService;
import com.example.tomatomall.vo.CartItemVO;
import com.example.tomatomall.vo.OrderVO;
import com.example.tomatomall.vo.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    CartService cartService;

    @Autowired
    OrderService orderService;

    @PostMapping("")
    public Response<CartShow> addCartItem(@RequestBody CartAdd cartAdd){
        Integer quantity = cartAdd.getQuantity();
        Integer productId = Integer.parseInt(cartAdd.getProductId());
        return Response.buildSuccess(cartService.addCartItem(productId, quantity));
    }

    @DeleteMapping("/{cartItemId}")
    public Response<String> deleteCartItem(@PathVariable Integer cartItemId){
        return Response.buildSuccess(cartService.deleteCartItem(cartItemId));
    }

    @PatchMapping("/{cartItemId}")
    public Response<String> changeProductInCartNum(@PathVariable Integer cartItemId, @RequestBody Map<String, Integer> requestBody){
        Integer quantity = requestBody.get("quantity");
        return Response.buildSuccess(cartService.changeProductInCartNum(cartItemId, quantity));
    }

    @GetMapping()
    public Response<List<CartShow>> getCartList(){
        return Response.buildSuccess(cartService.getCartList());
    }

    @PostMapping("checkout")
    public Response<RetOrderInfo> submitOrder(@RequestBody CheckoutRequest checkoutRequest){
        return Response.buildSuccess(orderService.submitOrder(checkoutRequest.getCartItemIds(), checkoutRequest.getPaymentMethod()));
    }

}

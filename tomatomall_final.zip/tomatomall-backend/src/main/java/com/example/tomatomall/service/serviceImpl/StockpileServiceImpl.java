package com.example.tomatomall.service.serviceImpl;

import com.example.tomatomall.configure.LockConfigure;
import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.CartItem;
import com.example.tomatomall.po.CartsOrdersRelation;
import com.example.tomatomall.po.Order;
import com.example.tomatomall.po.Stockpile;
import com.example.tomatomall.repository.*;
import com.example.tomatomall.service.StockpileService;
import com.example.tomatomall.vo.StockpileVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
public class StockpileServiceImpl implements StockpileService {

    @Autowired
    StockpileRepository stockpileRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    CartsOrdersRelationRepository cartsOrdersRelationRepository;

    @Autowired
    CartItemRepository cartItemRepository;

    //更新仓库
    @Override
    public String updateStockpile(Integer productId, Integer amount){
        if(productId == null) throw TomatoMallException.productNotExists();
        Stockpile stockpile = stockpileRepository.findByProductId(productId).orElseThrow(TomatoMallException::productNotExists);
        if(stockpile == null) throw TomatoMallException.productNotExists();
        stockpile.setAmount(amount);
        stockpileRepository.save(stockpile);
        return "调整库存成功";
    }

    //获取仓库
    @Override
    public StockpileVO getStockpile(Integer productId){
        if(productId == null) throw TomatoMallException.productNotExists();
        Stockpile stockpile = stockpileRepository.findByProductId(productId).orElseThrow(TomatoMallException::productNotExists);
        return stockpile.toVO();
    }


    //减少库存
    @Override
    public void reduceStock(String orderId){
        List<CartsOrdersRelation> cartsOrdersRelations = cartsOrdersRelationRepository.findByOrderId(Integer.parseInt(orderId));
        for(CartsOrdersRelation cartsOrdersRelation: cartsOrdersRelations) {
            Integer cartItemId = cartsOrdersRelation.getCartItemId();
            CartItem cartItem = cartItemRepository.findByCartItemId(cartItemId);
            Integer reduceAmount = cartItem.getQuantity();
            Stockpile stockpile = stockpileRepository.findByProductId(cartItem.getProductId()).orElseThrow(TomatoMallException::productNotExists);
            cartsOrdersRelationRepository.delete(cartsOrdersRelation);
            cartItemRepository.delete(cartItem);
            ReentrantLock lock = LockConfigure.getLock(cartItem.getProductId());


            lock.lock();
            try {
                Integer amount = stockpile.getAmount();
                stockpile.setAmount(amount - reduceAmount);
                Integer frozen = stockpile.getFrozen();
                stockpile.setFrozen(frozen - reduceAmount);
                stockpileRepository.save(stockpile);
            } finally {
                lock.unlock();
            }
        }


    }
}

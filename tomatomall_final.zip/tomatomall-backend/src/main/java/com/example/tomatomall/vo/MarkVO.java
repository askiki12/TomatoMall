package com.example.tomatomall.vo;


import com.example.tomatomall.configure.MarkStar;
import com.example.tomatomall.po.Mark;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MarkVO {

    private Integer id;

    private Integer productId;

    private Integer userId;

    private MarkStar markStar;

    public Mark toPO(){
        Mark mark = new Mark();
        mark.setId(id);
        mark.setUserId(userId);
        mark.setProductId(productId);
        mark.setMarkStar(markStar);
        return mark;
    }
}

package com.example.tomatomall.service;

import com.example.tomatomall.configure.CartShow;
import com.example.tomatomall.vo.CartItemVO;

import java.math.BigDecimal;
import java.util.List;

public interface CartService {

    CartShow addCartItem(Integer productId, Integer quantity);

    String deleteCartItem(Integer cartItemId);

    String changeProductInCartNum(Integer cartItemId, Integer quantity);

    List<CartShow> getCartList();

    BigDecimal getPrice(Integer id);

}

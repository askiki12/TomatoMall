package com.example.tomatomall.controller;

import com.example.tomatomall.service.ProductService;
import com.example.tomatomall.service.StockpileService;
import com.example.tomatomall.vo.ProductVO;
import com.example.tomatomall.vo.Response;
import com.example.tomatomall.vo.StockpileVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    StockpileService stockpileService;

    @GetMapping
    public Response<List<ProductVO>> getAllProducts(){
        return Response.buildSuccess(productService.getAllProducts());
    }

    @GetMapping("/{id}")
    public Response<ProductVO> getTheProducts(@PathVariable Integer id){
        return Response.buildSuccess(productService.getTheProduct(id));
    }

    @PutMapping
    public Response<String> updateProductInfo(@RequestBody ProductVO productVO){
        return Response.buildSuccess(productService.updateProductInfo(productVO));
    }

    @PostMapping
    public Response<ProductVO> addProduct(@RequestBody ProductVO productVO){
        return Response.buildSuccess(productService.addProduct(productVO));
    }

    @DeleteMapping("/{id}")
    public Response<String> deleteProduct(@PathVariable Integer id){
        return Response.buildSuccess(productService.deleteProduct(id));
    }

    @PatchMapping("/stockpile/{productId}")
    public Response<String> updateStockpile(@PathVariable Integer productId, @RequestBody Map<String, Integer> requestBody){
        Integer amount = requestBody.get("amount");
        return Response.buildSuccess(stockpileService.updateStockpile(productId, amount));
    }

    @GetMapping("/stockpile/{productId}")
    public Response<StockpileVO> getStockpile(@PathVariable Integer productId){
        return Response.buildSuccess(stockpileService.getStockpile(productId));
    }
}

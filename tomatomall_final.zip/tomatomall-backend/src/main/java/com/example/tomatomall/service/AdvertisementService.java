package com.example.tomatomall.service;

import com.example.tomatomall.vo.AdvertisementVO;

import java.util.List;

public interface AdvertisementService {

    AdvertisementVO createAdvertisement(AdvertisementVO advertisementVO);

    List<AdvertisementVO> getAllAdvertisement();

    String updateAdvertisement(AdvertisementVO advertisementVO);

    String deleteAdvertisement(Integer id);

}

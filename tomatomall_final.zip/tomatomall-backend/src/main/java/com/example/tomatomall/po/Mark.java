package com.example.tomatomall.po;

import com.example.tomatomall.configure.MarkStar;
import com.example.tomatomall.vo.MarkVO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "marks")
public class Mark {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "product_id")
    private Integer productId;

    @Column(name = "userId")
    private Integer userId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", insertable = false, updatable = false)
    private Product product;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId", insertable = false, updatable = false)
    private Account user;

    @Enumerated(EnumType.STRING)
    @Column(name = "mark_star")
    private MarkStar markStar;

    public MarkVO toVO(){
        MarkVO markVO = new MarkVO();
        markVO.setId(id);
        markVO.setProductId(productId);
        markVO.setUserId(userId);
        markVO.setMarkStar(markStar);
        return markVO;
    }
}

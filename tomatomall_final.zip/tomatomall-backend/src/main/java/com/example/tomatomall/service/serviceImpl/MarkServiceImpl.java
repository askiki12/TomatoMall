package com.example.tomatomall.service.serviceImpl;

import com.example.tomatomall.configure.MarkStar;
import com.example.tomatomall.exception.TomatoMallException;
import com.example.tomatomall.po.Mark;
import com.example.tomatomall.po.Product;
import com.example.tomatomall.repository.MarkRepository;
import com.example.tomatomall.repository.ProductRepository;
import com.example.tomatomall.service.MarkService;
import com.example.tomatomall.util.SecurityUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class MarkServiceImpl implements MarkService {

    @Autowired
    MarkRepository markRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    SecurityUtil securityUtil;

    //创建评分
    public String createMark(Integer productId, MarkStar markStar){
        Product product = productRepository.findById(productId).orElseThrow(TomatoMallException::productNotExists);
        Integer userId = securityUtil.getCurrentUser().getId();
        Mark mark = markRepository.findByProductIdAndUserId(productId, userId);
        if(mark != null) throw TomatoMallException.MarkAlreadyExists();
        Mark newmark = new Mark();
        newmark.setMarkStar(markStar);
        newmark.setUserId(userId);
        newmark.setProductId(productId);
        markRepository.save(newmark);
        updateProductMark(productId);
        return "创建成功";
    }

    //删除评分
    @Transactional
    public String deleteMark(Integer productId){
        Integer userId = securityUtil.getCurrentUser().getId();
        Product product = productRepository.findById(productId).orElseThrow(TomatoMallException::productNotExists);
        Mark mark = markRepository.findByProductIdAndUserId(productId, userId);
        if(mark == null) throw TomatoMallException.MarkNotExists();
        markRepository.deleteByProductIdAndUserId(productId, userId);
        updateProductMark(productId);
        return "删除成功";
    }

    //改变评分
    public String changeMark(Integer productId, MarkStar markStar){
        Product product = productRepository.findById(productId).orElseThrow(TomatoMallException::productNotExists);
        Integer userId = securityUtil.getCurrentUser().getId();
        Mark mark = markRepository.findByProductIdAndUserId(productId, userId);
        if(mark == null) throw TomatoMallException.MarkNotExists();
        mark.setMarkStar(markStar);
        markRepository.save(mark);
        updateProductMark(productId);
        return "更改成功";
    }


    //更新评分
    public String updateProductMark(Integer productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(TomatoMallException::productNotExists);

        List<Mark> marks = markRepository.findByProductId(productId);
        if (marks.isEmpty()) {
            return "0.0";
        }
        double total = 0.0;
        for (Mark mark : marks) {
            total += mark.getMarkStar().getValue();
        }
        double average = total / marks.size();
        product.setRate(average);
        productRepository.save(product);
        return String.format("%.1f", average);
    }

    //获取自己的评分
    public String getMyProductMark(Integer productId){
        Product product = productRepository.findById(productId)
                .orElseThrow(TomatoMallException::productNotExists);
        Integer userId = securityUtil.getCurrentUser().getId();
        Mark mark = markRepository.findByProductIdAndUserId(productId, userId);
        if(mark == null) throw TomatoMallException.MarkNotExists();
        return String.format("%d", mark.getMarkStar().getValue());
    }
}

# tomatomall-frontend

该前端代码仅实现了一个简单的导航栏和路由配置，供需要的同学作框架参考，具体实现不做限制。如果代码无法正常运行或展示，考虑是否安装了所有需要的包，如`element-plus`、`vue-router`等

## Recommended IDE Setup

[VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Customize configuration

See [Vite Configuration Reference](https://vite.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```

import { axios } from '../utils/request';

// 定义商品列表接口返回的数据类型
interface ProductSpecification {
    id: string | number; // id可能是字符串或数字，根据实际情况调整
    item: string;
    value: string;
    productId: string | number; // Ensure productID can also be number
}

export interface Product {
    id: number;
    title: string;
    price: number;
    rate: number;
    description: string;
    cover: string;
    detail: string;
    specifications: ProductSpecification[];
}

interface ProductUpdate {
    id: number;
    title?: string;
    price?: number;
    rate?: number;
    description?: string;
    cover?: string;
    detail?: string;
    specifications?: ProductSpecification[];
}

interface ProductCreate {
    title: string;
    price: number;
    rate: number;
    description?: string;
    cover?: string;
    detail?: string;
    specifications?: ProductSpecification[];
}

interface StockpileData {
    id: string;
    amount: number;
    frozen: number;
    productId: string;
}

interface StockpileDataEdit {
    productId: string;
    amount: number;
}

interface ApiResponse<T> {
    code: string;
    data: T;
    msg: string | null;
}

// 获取商品列表的 API 方法
export const getProductList = async (): Promise<ApiResponse<Product[]>> => {
    try {
        // return product_list; // development mode

        // production mode
        const response = await axios.get<ApiResponse<Product[]>>('/products');
        return response.data;
    } catch (error: any) {
        // 统一处理错误，可以抛出错误或者返回默认值
        console.error('Error fetching product list:', error);
        throw new Error('Failed to fetch products'); // Rethrow with a standard error message
        // 或者返回默认值： return { code: '500', data: [], msg: 'Failed to fetch products' };
    }
};

// 获取指定商品信息的 API 方法
export const getProductById = async (id: string | number): Promise<ApiResponse<Product | null>> => {
    try {
        // return product_sp; // development mode

        // production mode
        const response = await axios.get<ApiResponse<Product>>(`/products/${id}`);
        return response.data;
    } catch (error: any) {
        console.error(`Error fetching product with id ${id}:`, error);
        throw new Error('Failed to fetch product'); // Rethrow with standard error
    }
};

export const updateProduct = async (payload: ProductUpdate): Promise<ApiResponse<string | null>> => {
    try {
        // return product_update_successful; // development mode

        // production mode
        const response = await axios.put<ApiResponse<string>>(`/products`, payload);
        return response.data;
    } catch (error: any) {
        console.error(`Error updating product with id ${payload.id}:`, error);
        throw new Error('Failed to update product');
    }
};

// 获取指定商品库存的 API 方法
export const getProductStockpile = async (productId: string | number): Promise<ApiResponse<StockpileData | null>> => {
    try {
        // return product_stockpile; // development mode

        // production mode
        // console.log('Fetching stockpile for product id:', productId);
        const response = await axios.get<ApiResponse<StockpileData>>(`/products/stockpile/${productId}`);
        return response.data;
    } catch (error: any) {
        console.error(`Error fetching stockpile for product id ${productId}:`, error);
        throw new Error('Failed to fetch product stockpile');
    }
};

// 删除商品的 API 方法
export const deleteProduct = async (id: string | number): Promise<ApiResponse<string | null>> => {
    try {
        // return product_delete_successful; // development mode

        // production mode
        const response = await axios.delete<ApiResponse<string>>(`/products/${id}`);
        return response.data;
    } catch (error: any) {
        console.error(`Error deleting product with id ${id}:`, error);
        throw new Error('Failed to delete product');
    }
};

// 增加商品的 API 方法
export const createProduct = async (product: ProductCreate): Promise<ApiResponse<Product | null>> => {
    try {
        console.log('Creating product:', product);
        const response = await axios.post<ApiResponse<Product>>(`/products`, product);
        return response.data;
    } catch (error: any) {
        console.error(`Error creating product:`, error);
        throw new Error('Failed to create product');
    }
};

// 调整指定商品的库存的 API 方法
export const adjustProductStockpile = async (payload: StockpileDataEdit): Promise<ApiResponse<string | null>> => {
    try {
        console.log(`Adjusting stockpile for product id ${payload.productId}`);
        const response = await axios.patch<ApiResponse<string>>(
            `/products/stockpile/${payload.productId}`,
            payload,
        );
        console.log('Response:', response.data);
        return response.data;
    } catch (error: any) {
        console.error(`Error adjusting stockpile for product id ${payload.productId}:`, error);
        if (error.response) {
            console.error('Response data:', error.response.data);
        }
        throw new Error('Failed to adjust stockpile');
    }
};

interface MarkRequest {
    productId: number;
    markStar: number;
}

// 获取商品评分
export const getProductMark = async (productId: number): Promise<ApiResponse<string>> => {
    try {
        const response = await axios.get<ApiResponse<string>>(`/marks/${productId}`);
        return response.data;
    } catch (error: any) {
        console.error(`Error fetching mark for product id ${productId}:`, error);
        throw new Error('Failed to fetch mark');
    }
};

// 创建商品评分
export const createProductMark = async (markRequest: MarkRequest): Promise<ApiResponse<string>> => {
    try {
        const response = await axios.post<ApiResponse<string>>(`/marks/create`, markRequest);
        return response.data;
    } catch (error: any) {
        console.error(`Error creating mark for product id ${markRequest.productId}:`, error);
        throw new Error('Failed to create mark');
    }
};

// 修改商品评分
export const changeProductMark = async (markRequest: MarkRequest): Promise<ApiResponse<string>> => {
    try {
        const response = await axios.post<ApiResponse<string>>(`/marks/change`, markRequest);
        return response.data;
    } catch (error: any) {
        console.error(`Error changing mark for product id ${markRequest.productId}:`, error);
        throw new Error('Failed to change mark');
    }
};

// 删除商品评分
export const deleteProductMark = async (productId: number): Promise<ApiResponse<string>> => {
    try {
        const response = await axios.delete<ApiResponse<string>>(`/marks/${productId}`);
        return response.data;
    } catch (error: any) {
        console.error(`Error deleting mark for product id ${productId}:`, error);
        throw new Error('Failed to delete mark');
    }
};

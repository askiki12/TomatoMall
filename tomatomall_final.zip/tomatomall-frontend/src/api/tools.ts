import {axios} from '../utils/request'
// 上传图片文件
export const uploadImage = (payload: any) => {
    return axios.post('/tools/images', payload, {
        headers: {
            'Content-Type': "multipart/form-data;"
        }
    })
        .then(res => {
            return res
        })
}
import { axios } from '../utils/request';

interface ApiResponse<T> {
    code: string;
    data: T;
    msg: string | null;
}

// 定义评论的数据结构
export interface Comment {
    id: number;
    productId: number;
    userId: number;
    content: string;
}

export interface CommentCreatePayload {
    productId: number;
    content: string;
}

export interface CommentWithUsername extends Comment {
    username?: string; // 添加 username 属性
}

export const getCommentsByProductId = async (productId: number): Promise<ApiResponse<Comment[]>> => {
    try {
        const response = await axios.get<ApiResponse<Comment[]>>(`/comments/${productId}`);
        return response.data;
    } catch (error: any) {
        console.error(`Error fetching comments for product id ${productId}:`, error);
        return {
            code: error.response?.data?.code || '500',
            data: [],
            msg: error.response?.data?.msg || `Failed to fetch comments for product id ${productId}`
        };
    }
};

export const createComment = async (payload: CommentCreatePayload): Promise<ApiResponse<string>> => {
    try {
        const response = await axios.post<ApiResponse<string>>('/comments/create', payload);
        return response.data;
    } catch (error: any) {
        console.error('Error creating comment:', error);
        return {
            code: error.response?.data?.code || '500',
            data: '',
            msg: error.response?.data?.msg || 'Failed to create comment'
        };
    }
};

export const deleteComment = async (commentId: number): Promise<ApiResponse<string>> => {
    try {
        const response = await axios.delete<ApiResponse<string>>(`/comments/${commentId}`);
        return response.data;
    } catch (error: any) {
        console.error(`Error deleting comment with id ${commentId}:`, error);
        return {
            code: error.response?.data?.code || '500',
            data: '', // 或者 null
            msg: error.response?.data?.msg || `Failed to delete comment with id ${commentId}`
        };
    }
};
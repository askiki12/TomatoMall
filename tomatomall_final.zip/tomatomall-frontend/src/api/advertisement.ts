import { axios } from '../utils/request';

export interface Advertisement {
    id: number;
    title: string;
    content: string;
    imgUrl: string;
    productId: string;
}

// 通用响应接口
interface ApiResponse<T> {
    code: string;
    data: T;
    msg: string | null;
}

// 获取所有广告信息
export async function getAdvertisements(): Promise<ApiResponse<Advertisement[]>> {
    try {
        const response = await axios.get('/advertisements');
        console.log("获取广告信息成功:", response.data);
        return response.data;
    } catch (error) {
        console.error("获取广告信息失败:", error);
        throw error;
    }
}

// 更新广告信息的 payload 类型
interface UpdateAdvertisementPayload {
    id: number; // 必填
    title?: string; // 选填
    content?: string; // 选填
    imgUrl?: string; // 选填
    productId: string; // 必填
}

// 更新广告信息
export async function updateAdvertisement(payload: UpdateAdvertisementPayload): Promise<ApiResponse<Advertisement>> {
    try {
        console.log("更新广告信息的 payload:", payload);
        const response = await axios.put('/advertisements', payload);
        console.log("更新广告信息成功:", response.data);
        return response.data;
    } catch (error) {
        console.error("更新广告信息失败:", error);
        throw error;
    }
}

// 创建广告信息的 payload 类型
interface CreateAdvertisementPayload {
    title: string; // 必填
    content: string; // 必填
    imgUrl: string; // 必填
    productId: string; // 必填
}

// 创建广告
export async function createAdvertisement(payload: CreateAdvertisementPayload): Promise<ApiResponse<Advertisement>> {
    try {
        const response = await axios.post('/advertisements', payload);
        console.log("创建广告成功:", response.data);
        return response.data;
    } catch (error) {
        console.error("创建广告失败:", error);
        throw error;
    }
}

// 删除广告
export async function deleteAdvertisement(id: number): Promise<ApiResponse<string>> {
    try {
        const response = await axios.delete(`/advertisements/${id}`);
        console.log("删除广告成功:", response.data);
        return response.data;
    } catch (error) {
        console.error("删除广告失败:", error);
        throw error;
    }
}
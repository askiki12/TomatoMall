import { axios } from '../utils/request';

export interface ApiResponse<T> {
    code: string;
    msg: string | null;
    data: T;
}

interface UserDetail {
    id: number; // <--- 新增：用户ID
    username: string;
    name: string;
    role: string;
    avatar: string;
    telephone: string;
    email: string;
    location: string;
}

// 获取用户详情
export async function getUserDetail(username: string): Promise<{ code: string; msg: string | null; data: UserDetail }> {
    try {
        const response = await axios.get(`/accounts/${username}`, {
            headers: {
                token: sessionStorage.getItem('token') ?? ''
            }
        });
        return response.data; // 从 response 中提取 data
    } catch (error) {
        // 在这里处理错误，例如显示一个全局的错误提示
        console.error("获取用户详情失败:", error);
        throw error; // 抛出错误，以便组件能够捕获并进行处理
    }
}

interface CreateUserPayload {
    username: string;
    password?: string; // password 是可选的，因为后端可能自动生成
    name: string; //真实姓名
    role: string; //用户身份区分，分管理员和普通用户 (admin/user)
    avatar?: string;    // avatar 是可选的
    telephone?: string; // 手机号, 格式必须为 1xxxxxxxxxx
    email?: string; //邮箱，必须符合 Email 格式
    location?: string; //位置
}

// 创建用户
export async function createUser(payload: CreateUserPayload): Promise<{ code: string; msg: string | null; data: string }> {
    try {
        const response = await axios.post('/accounts', payload);
        return response.data; // 返回 response.data
    } catch (error) {
        console.error("创建用户失败:", error);
        throw error;
    }
}

interface LoginPayload {
    username: string;
    password?: string;
}

// 登录
export async function login(payload: LoginPayload): Promise<{ code: string; msg: string | null; data: any }> { // 修改 data 类型为 any
    try {
        const response = await axios.post('/accounts/login', payload);
        return response.data.data; // 返回 response.data
    } catch (error) {
        console.error("登录失败:", error);
        throw error;
    }
}

export interface UpdateUserPayload {
    username: string;      //用户名
    password?: string;     //密码
    name?: string;         //姓名
    role?: string;         //角色
    avatar?: string;       //头像
    telephone?: string;    //电话
    email?: string;        //邮箱
    location?: string;      //地区
}

// 更新用户信息
export async function updateUserInfo(payload: UpdateUserPayload): Promise<{ code: string; msg: string | null; data: string }> {
    try {
        console.log("更新用户信息的 payload:", payload); // 打印 payload 以调试
        const response = await axios.put('/accounts', payload, {
            headers: {
                'token': sessionStorage.getItem('token') ?? ''
            }
        });
        return response.data;
    } catch (error) {
        console.error("更新用户信息失败:", error);
        throw error;
    }
}

// --- 新增方法 (已修改) ---

// 获取当前登录用户的信息。
// 返回类型修改为 ApiResponse<UserDetail>，因为实际返回的 data 是一个 UserDetail 对象
export async function getCurrentUser(): Promise<ApiResponse<UserDetail>> { // <--- 关键修改
    try {
        // 明确告诉 axios 期望的响应数据结构
        const response = await axios.get<ApiResponse<UserDetail>>('/accounts', { // <--- 关键修改
            headers: {
                'token': sessionStorage.getItem('token') ?? ''
            }
        });
        return response.data; // response.data 此时是 { code: "200", msg: "...", data: UserDetailObject }
    } catch (error) {
        console.error("获取当前用户信息失败:", error);
        throw error;
    }
}

// 根据用户ID获取用户名。
// 返回类型修改为 ApiResponse<string>，因为实际返回的 data 是一个字符串
export async function getUsernameById(id: number): Promise<ApiResponse<string>> { // <--- 关键修改
    try {
        // 明确告诉 axios 期望的响应数据结构
        const response = await axios.get<ApiResponse<string>>(`/accounts/name/${id}`, { // <--- 关键修改
            headers: {
                'token': sessionStorage.getItem('token') ?? ''
            }
        });
        return response.data; // response.data 此时是 { code: "200", msg: "...", data: "usernameString" }
    } catch (error) {
        console.error(`获取ID为 ${id} 的用户名失败:`, error);
        throw error;
    }
}
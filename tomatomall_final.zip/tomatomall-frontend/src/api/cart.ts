import { axios } from '../utils/request';

interface ApiResponse<T> {
    code: string;
    data: T;
    msg: string | null;
}

interface AddToCartPayload {
    productId: string;
    quantity: number;
}

interface AddToCartResponse {
    code: string;
    msg: string | null;
    data: {
        cartItemId: string;
        productId: string;
        title: string;
        price: number;
        description: string;
        cover: string;
        detail: string;
        quantity: number;
    };
}

// 添加商品到购物车
export async function addToCart(payload: AddToCartPayload): Promise<AddToCartResponse> {
    try {
        const response = await axios.post('/cart', payload);
        return response.data;
    } catch (error) {
        console.error("添加商品到购物车失败:", error);
        throw error;
    }
}

interface DeleteCartItemResponse {
    code: string;
    msg: string | null;
    data: string | null;  // Data can be string (success) or null (error)
}

// 删除购物车商品
export async function deleteCartItem(cartItemId: string): Promise<DeleteCartItemResponse> {
    try {
        const response = await axios.delete(`/cart/${cartItemId}`);
        return response.data;
    } catch (error) {
        console.error("删除购物车商品失败:", error);
        throw error;
    }
}

interface UpdateCartItemQuantityPayload {
    quantity: number;
}

interface UpdateCartItemQuantityResponse {
    code: string;
    msg: string | null;
    data: string | null;
}

// 修改购物车商品数量
export async function updateCartItemQuantity(cartItemId: string, payload: UpdateCartItemQuantityPayload): Promise<UpdateCartItemQuantityResponse> {
    try {
        const response = await axios.patch(`/cart/${cartItemId}`, payload);
        return response.data;
    } catch (error) {
        console.error("修改购物车商品数量失败:", error);
        throw error;
    }
}

interface CartItem {
    cartItemId: string;
    productId: string;
    title: string;
    price: number;
    description: string;
    cover: string;
    detail: string;
    quantity: number;
}

interface GetCartResponse {
    code: string;
    msg: string | null;
    data: CartItem[]; // change here
}

// 获取购物车商品列表
export async function getCart(): Promise<GetCartResponse> {
    try {
        const response = await axios.get('/cart/');
        return response.data;
    } catch (error) {
        console.error("获取购物车商品列表失败:", error);
        throw error;
    }
}

export interface CheckoutPayload {
    cartItemIds: string[];
    addressInfo: {
        name: string;
        phone: string;
        address: string;
    };
    paymentMethod: string; 
}

export interface CheckoutResponse {
    code: string;
    msg: string | null;
    data: {
        orderId: number; // 订单ID
        username: string; // 用户名
        totalAmount: number; // 订单总金额
        paymentMethod: string; // 支付方式
        createTime: string; // 订单创建时间
        status: string; // 订单状态
    } | null;
}

export async function checkout(payload: CheckoutPayload): Promise<CheckoutResponse> {
    try {
        console.log("结算请求参数:", payload);
        const response = await axios.post('/cart/checkout', payload);
        return response.data;
    } catch (error) {
        console.error("结算失败:", error);
        throw error;
    }
}

export interface PayResponse {
    code: string;
    msg: string | null;
    data: {
        paymentForm: string; // 支付宝支付表单HTML
        orderId: number; // 订单ID
        totalAmount: number; // 订单总金额
        paymentMethod: string; // 支付方式，例如：Alipay
    } | null;
}

export async function pay(orderId: number): Promise<PayResponse> {
    try {
        const response = await axios.post(`/orders/${orderId}/pay`);
        return response.data;
    } catch (error) {
        console.error("支付失败:", error);
        throw error;
    }
}

export async function status(orderId: number): Promise<ApiResponse<string>> {
    try {
        const response = await axios.get(`/orders/status/${orderId}`);
        return response.data;
    } catch (error) {
        console.error("支付失败:", error);
        throw error;
    }
}
import { createRouter, createWebHistory } from 'vue-router';
import Home from '../pages/home.vue';
import CartPage from "../pages/CartPage.vue";
import WarehousePage from "../pages/WarehousePage.vue";
import ProductDetail from '../pages/product_detail.vue';
//登录、注册、个人信息页面
import Login from '../pages/Login.vue';
import Register from '../pages/Register.vue';
import Profile from '../pages/Profile.vue';
import Advertisement from '../pages/AdPage.vue';

const routes = [
    {
        path: '/',
        redirect: '/login',
    },
    {
        path: '/home',
        name: 'home',
        component: Home,
        meta: { requiresAuth: true }  // 添加
    },
    {
        path: '/cart',
        name: 'cart',
        component: CartPage,
        meta: { requiresAuth: true }  // 添加
    },
    {
        path: '/warehouse',
        name: 'warehouse',
        component: WarehousePage,
        meta: { requiresAuth: true }  // 添加
    },
    {
        path: '/advertisement',
        name: 'advertisement',
        component: Advertisement,
        meta: { requiresAuth: true }  // 添加
    },

    //其他路由配置

    {
        path: '/login',
        name: 'login',
        component: Login
    },
    {
        path: '/register',
        name: 'register',
        component: Register
    },
    {
        path: '/profile',
        name: 'profile',
        component: Profile,
        meta: { requiresAuth: true } //  添加
    },

    {
        path: '/product/:id',  // 定义商品详情页的路由
        name: 'product-detail',
        component: ProductDetail,
        meta: { requiresAuth: true }
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes
});

export default router;
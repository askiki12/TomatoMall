<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRouter, useRoute } from "vue-router";
import { ElMessage, ElLoading } from "element-plus";
import {
    getProductList,
    deleteProduct,
    getProductStockpile,
} from "../api/product";
import EditProductDialog from "../components/Tomato-Dialog/EditProductDialog.vue";
import CreateProductDialog from "../components/Tomato-Dialog/CreateProductDialog.vue";
import AddAdDialog from "../components/Tomato-Dialog/AddAdDialog.vue";

interface Product {
    id: number;
    title: string;
    price: number;
    rate: number;
    description: string;
    cover: string;
    detail: string;
    specifications: any[];
    amount?: number;
    frozen?: number;
}

const products = ref<Product[]>([]);
const error = ref<string | null>(null);

const role = sessionStorage.getItem("role");
if (role !== "admin") {
    ElMessage.error("没有权限访问该页面。");
    setTimeout(() => {
        router.push("/home");
    }, 2000);
}

const router = useRouter();

const addAdvertisementDialogVisible = ref(false);
const AdProductId = ref<string>("0");

const fetchProducts = async () => {
    try {
        const response = await getProductList();
        if (response.code === "200") {
            products.value = response.data;
        } else {
            error.value = response.msg || "获取商品列表失败。";
        }
    } catch (e: any) {
        error.value = e.message || "发生了一个意外错误。";
    }
};

const fetchStockPile = async (productId: string) => {
    try {
        const response = await getProductStockpile(productId);
        if (response.code === "200") {
            return response.data;
        } else {
            error.value = response.msg || "获取商品库存失败。";
        }
    } catch (e: any) {
        error.value = e.message || "发生了一个意外错误。";
    }
};

const fetchAllStockPile = async () => {
    for (const product of products.value) {
        const stockpile = await fetchStockPile(product.id.toString());
        product.amount = stockpile ? stockpile.amount : 0;
        product.frozen = stockpile ? stockpile.frozen : 0;
    }
};

const route = useRoute();
const fromAdvertisement = ref(false);

onMounted(async () => {
    if (route.query.from === "advertisement") {
        fromAdvertisement.value = true;
    }
    const loading = ElLoading.service({
        lock: true,
        text: "加载购物车中...",
        background: "rgba(0, 0, 0, 0.3)",
    });
    error.value = null;
    await Promise.all([fetchProducts()]);
    fetchAllStockPile();
    loading.close();
});

const goToProductDetail = (productId: number) => {
    router.push(`/product/${productId}`);
};

const removeProduct = async (productId: number) => {
    try {
        const response = await deleteProduct(productId);
        if (response.code === "200") {
            products.value = products.value.filter(
                (product) => product.id !== productId
            );
            ElMessage.success("删除成功！");
        } else {
            ElMessage.error(response.msg || "删除商品失败。");
        }
    } catch (e: any) {
        ElMessage.error(e.message || "发生了一个意外错误。");
    }
};

const addDialogVisible = ref(false);

const editDialogVisible = ref(false);

const currentEditProduct = ref<Product | null>(null);

const openAddDialog = () => {
    addDialogVisible.value = true;
};

const closeAddDialog = () => {
    addDialogVisible.value = false;
    fetchProducts();
    fetchAllStockPile();
};

const openEditDialog = (product: Product) => {
    currentEditProduct.value = product;
    editDialogVisible.value = true;
};

const closeEditDialog = async () => {
    editDialogVisible.value = false;
    await Promise.all([fetchProducts()]);
    fetchAllStockPile();
};

const openAddAdvertisementDialog = (productId: number) => {
    AdProductId.value = productId.toString();
    addAdvertisementDialogVisible.value = true;
};

const handleAdvertisementDialogClose = () => {
    addAdvertisementDialogVisible.value = false;
    if (fromAdvertisement.value) {
        router.push("/advertisement");
    } else {
        fetchProducts();
        fetchAllStockPile();
    }
};

const formatPrice = (_row: Product, _column: any, cellValue: number) =>
    `$${cellValue}`;
</script>

<template>
    <div class="container" v-if="role === 'admin'">
        <div class="product-edit-list">
            <div class="header">
                <h1 v-if="!fromAdvertisement">商品列表</h1>
                <h1 v-else>~选择要添加广告的商品~</h1>
                <el-button
                    type="primary"
                    @click="openAddDialog"
                    class="add-product-button"
                    v-if="!fromAdvertisement"
                    >添加商品</el-button
                >
            </div>
            <el-table
                v-if="products.length > 0"
                :data="products"
                style="width: 100%; text-align: center"
                border
            >
                <el-table-column prop="title" label="商品名称" align="center" />
                <el-table-column
                    prop="price"
                    label="价格"
                    align="center"
                    :formatter="formatPrice"
                />
                <el-table-column prop="rate" label="评分" align="center" />
                <el-table-column
                    prop="description"
                    label="描述"
                    align="center"
                />
                <el-table-column prop="amount" label="库存" align="center" />
                <el-table-column
                    prop="frozen"
                    label="冻结库存"
                    align="center"
                />
                <el-table-column label="操作" align="center">
                    <template #default="scope">
                        <el-button
                            type="text"
                            @click="goToProductDetail(scope.row.id)"
                            >查看详情</el-button
                        >
                        <el-button
                            type="text"
                            @click="openEditDialog(scope.row)"
                            v-if="!fromAdvertisement"
                            >编辑</el-button
                        >
                        <el-button
                            type="text"
                            @click="removeProduct(scope.row.id)"
                            v-if="!fromAdvertisement"
                            >删除</el-button
                        >
                        <el-button
                            type="text"
                            @click="openAddAdvertisementDialog(scope.row.id)"
                            v-if="fromAdvertisement"
                        >
                            添加广告
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
    </div>
    <EditProductDialog
        :visible="editDialogVisible"
        :product="currentEditProduct"
        @close="closeEditDialog"
    />
    <CreateProductDialog :visible="addDialogVisible" @close="closeAddDialog" />
    <AddAdDialog
        :visible="addAdvertisementDialogVisible"
        :productId="AdProductId"
        @update:visible="addAdvertisementDialogVisible = $event"
        @close="handleAdvertisementDialogClose"
    />
</template>

<style scoped>
.container {
    width: 100%;
    min-height: 100vh;
    padding: 40px 20px;
    background-color: #f8f9fa;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    box-sizing: border-box;
    height: 100vh;
    position: fixed;
    top: 50px;
    left: 0;
    overflow: scroll;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.add-product-button {
    margin-left: auto;
}

.product-edit-list {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background-color: white;
    border-radius: 16px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.product-edit-list h1 {
    font-size: 2rem;
    color: #2c3e50;
    margin-bottom: 20px;
}

.error-message {
    color: #c0392b;
    padding: 20px;
    background: #f9ebeb;
    border-radius: 8px;
    margin: 20px auto;
    max-width: 600px;
}

@media (max-width: 768px) {
    .container {
        padding: 20px 10px;
    }
}

.no-permission {
    color: red;
    font-weight: bold;
    font-size: 33px;
    text-align: center;
    width: 800px;
    margin-left: 100px;
}
</style>

<script setup lang="ts">
import { ref, computed, watch } from "vue";
import { useRouter } from "vue-router";
import { createUser } from "../api/user";
import { uploadImage } from "../api/tools"; // 引入上传图片的 API
import { ElMessage } from "element-plus";

const username = ref("");
const password = ref("");
const name = ref("");
const role = ref("user");
const telephone = ref("");
const email = ref("");
const location = ref("");
const avatarUrl = ref(""); // 用于存储头像 URL
const avatarFileList = ref([]); // 用于存储头像文件列表
const avatarUploadError = ref(""); // 用于存储头像上传错误信息
const router = useRouter();
const telephoneError = ref("");
const emailError = ref("");
const currentStep = ref(1); // 当前步骤

// 验证函数
const validatePhone = (phone: any) => /^1[3-9]\d{9}$/.test(phone);
const validateEmail = (email: any) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

// 监听电话号码变化
watch(telephone, (newTelephone) => {
    if (newTelephone) {
        telephoneError.value = validatePhone(newTelephone)
            ? ""
            : "电话号码格式错误";
    } else {
        telephoneError.value = "";
    }
});

// 监听邮箱变化
watch(email, (newEmail) => {
    if (newEmail) {
        emailError.value = validateEmail(newEmail) ? "" : "邮箱格式错误";
    } else {
        emailError.value = "";
    }
});

// 计算属性，检查表单是否有效
const isRequiredFormValid = computed(
    () => username.value && password.value && name.value && role.value
);
const isOptionalFormValid = computed(
    () => !telephoneError.value && !emailError.value
);

const nextStep = () => {
    if (isRequiredFormValid.value) {
        currentStep.value = 2;
    } else {
        ElMessage.error("请填写所有必填项");
    }
};

const backStep = () => {
    currentStep.value = 1;
};

const beforeAvatarUpload = (file: any) => {
    const isJPG =
        file.type === "image/jpeg" ||
        file.type === "image/png" ||
        file.type === "image/gif";
    const isLt2M = file.size / 1024 / 1024 < 2;

    if (!isJPG) {
        ElMessage.error("上传头像只能是 JPG/PNG/GIF 格式!");
        return false;
    }
    if (!isLt2M) {
        ElMessage.error("上传头像大小不能超过 2MB!");
        return false;
    }
    return true;
};

const handleAvatarRemove = () => {
    avatarUrl.value = ""; // 清空头像 URL
    avatarFileList.value = [];
};

const handleAvatarExceed = () => {
    ElMessage.warning(`当前限制选择 1 个文件`);
};

const uploadAvatar = async (file: any) => {
    const loading = ElMessage({
        message: "头像上传中...",
        type: "info",
        duration: 0,
        showClose: true,
    });

    try {
        const formData = new FormData();
        formData.append("file", file);

        const res = await uploadImage(formData);

        if (res.data.code === "200") {
            console.log("头像上传成功，URL:", res.data);
            avatarUrl.value = res.data.data; // 存储头像 URL
            avatarUploadError.value = "";
        } else {
            console.error("头像上传失败，响应:", res);
            avatarUploadError.value =
                "头像上传失败: " + (res.data.msg || "Unknown error");
            ElMessage.error(avatarUploadError.value);
        }
    } catch (e) {
        console.error("头像上传过程中发生错误:", e);
        avatarUploadError.value = "头像上传过程中发生错误，请重试。";
        ElMessage.error(avatarUploadError.value);
    } finally {
        loading.close();
    }
};

const register = async () => {
    try {
        if (avatarFileList.value.length > 0) {
            const file = (avatarFileList.value[0] as any).raw;
            await uploadAvatar(file); // 上传头像
        }

        const payload = {
            username: username.value,
            password: password.value,
            name: name.value,
            role: role.value,
            telephone: telephone.value,
            email: email.value,
            location: location.value,
            avatar: avatarUrl.value, // 添加头像 URL 到注册数据中
        };

        console.log("注册数据:", payload); // 调试信息

        const response = await createUser(payload);

        if (response.code === "200") {
            ElMessage.success("注册成功！");
            await router.push("/login");
        } else {
            ElMessage.error(`注册失败: ${response.msg}`);
        }
    } catch (error) {
        console.error("注册错误:", error);
        ElMessage.error("注册过程中发生错误，请重试。");
    }
};
</script>

<template>
    <div class="register-container">
        <div class="register-box">
            <h1>注册</h1>
            <el-steps
                :active="currentStep"
                finish-status="success"
                simple
                style="margin-bottom: 20px"
            >
                <el-step title="必填项" />
                <el-step title="选填项" />
            </el-steps>
            <div v-if="currentStep === 1">
                <div class="input-group">
                    <label for="username">用户名*</label>
                    <input
                        type="text"
                        id="username"
                        v-model="username"
                        placeholder="请输入用户名"
                    />
                </div>
                <div class="input-group">
                    <label for="password">密码*</label>
                    <input
                        type="password"
                        id="password"
                        v-model="password"
                        placeholder="请输入密码"
                    />
                </div>
                <div class="input-group double-input">
                    <div class="input-half">
                        <label for="name">真实姓名*</label>
                        <input
                            type="text"
                            id="name"
                            v-model="name"
                            placeholder="请输入真实姓名"
                        />
                    </div>
                    <div class="input-half">
                        <label for="role">用户身份*</label>
                        <el-select
                            v-model="role"
                            placeholder="请选择用户身份"
                            class="role-select"
                        >
                            <el-option label="普通用户" value="user" />
                            <el-option label="管理员" value="admin" />
                        </el-select>
                    </div>
                </div>
                <button
                    @click="nextStep"
                    class="next-button"
                    :disabled="!isRequiredFormValid"
                >
                    下一步
                </button>
            </div>
            <div v-else>
                <div class="input-group">
                    <label for="avatar">头像</label>
                    <el-upload
                        v-model:file-list="avatarFileList"
                        :limit="1"
                        :on-exceed="handleAvatarExceed"
                        :on-remove="handleAvatarRemove"
                        class="avatar-uploader"
                        list-type="picture-card"
                        :auto-upload="false"
                        :before-upload="beforeAvatarUpload"
                        accept="image/*"
                    >
                        <template #trigger>
                            <div class="upload-content">
                                <el-icon class="upload-icon"
                                    ><UploadFilled
                                /></el-icon>
                                <div class="upload-text">
                                    <p class="main-text">点击上传头像</p>
                                    <p class="sub-text">
                                        建议尺寸 1:1，最大2MB
                                    </p>
                                </div>
                            </div>
                        </template>
                    </el-upload>
                    <p v-if="avatarUploadError" class="error-message">
                        {{ avatarUploadError }}
                    </p>
                </div>
                <div class="input-group">
                    <label for="telephone">手机号</label>
                    <input
                        type="text"
                        id="telephone"
                        v-model="telephone"
                        placeholder="请输入手机号 (可选)"
                    />
                    <p v-if="telephoneError" class="error-message">
                        {{ telephoneError }}
                    </p>
                </div>
                <div class="input-group">
                    <label for="email">邮箱</label>
                    <input
                        type="email"
                        id="email"
                        v-model="email"
                        placeholder="请输入邮箱 (可选)"
                    />
                    <p v-if="emailError" class="error-message">
                        {{ emailError }}
                    </p>
                </div>
                <div class="input-group">
                    <label for="location">位置</label>
                    <input
                        type="text"
                        id="location"
                        v-model="location"
                        placeholder="请输入位置 (可选)"
                    />
                </div>
                <div class="button-group">
                    <button @click="backStep" class="back-button">返回</button>
                    <button
                        @click="register"
                        class="register-button"
                        :disabled="!isOptionalFormValid"
                    >
                        提交
                    </button>
                </div>
            </div>
            <p class="login-link">
                已有账号？ <router-link to="/login">立即登录</router-link>
            </p>
        </div>
    </div>
</template>

<style scoped>
.avatar-uploader {
    width: 100%;
    display: flex;
    justify-content: flex-start;
}

.avatar-uploader :deep(.el-upload) {
    width: 150px;
    height: 150px;
    border: 2px dashed #dcdfe6;
    border-radius: 8px;
    transition: border-color 0.3s;
    margin-bottom: 10px;
}

.avatar-uploader :deep(.el-upload):hover {
    border-color: #409eff;
}

.upload-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    padding: 20px;
}

.upload-icon {
    font-size: 24px;
    color: #c0c4cc;
    margin-bottom: 12px;
}

.upload-text {
    text-align: center;
}

.upload-text .main-text {
    color: #303133;
    margin: 0 0 4px;
    font-weight: 500;
}

.upload-text .sub-text {
    color: #909399;
    margin: 0;
    font-size: 12px;
}
.register-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: #f0f2f5;
    padding: 0;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    position: fixed;
    top: 0;
    left: 0;
}

.register-box {
    width: 100%;
    max-width: 600px;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
    margin: 0 20px;
    box-sizing: border-box;
}

.register-box h1 {
    margin-bottom: 20px;
    color: #333;
    font-size: 2rem;
}

.input-group {
    margin-bottom: 10px;
    text-align: left;
}

.input-group label {
    display: block;
    margin-bottom: 8px;
    color: #555;
    font-weight: bold;
}

.input-group input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 1rem;
    transition: border-color 0.2s;
}

.input-group input:focus {
    border-color: #007bff;
    outline: none;
}

.double-input {
    display: flex;
    justify-content: space-between;
    gap: 2%;
}

.input-half {
    flex: 1;
    margin-right: 10px;
}

.input-half:last-child {
    margin-right: 0;
}

.next-button,
.back-button,
.register-button {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 4px;
    font-size: 1.1rem;
    cursor: pointer;
    transition: background-color 0.2s;
    margin-top: 10px;
}

.next-button,
.register-button {
    background-color: #28a745;
    color: #fff;
}

.next-button:hover,
.register-button:hover {
    background-color: #218838;
}

.back-button {
    background-color: #007bff;
    color: #fff;
}

.back-button:hover {
    background-color: #0056b3;
}

.next-button:disabled,
.register-button:disabled {
    background-color: #cccccc;
    cursor: not-allowed;
    color: #666666;
}

.button-group {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    margin-top: 10px;
    margin-bottom: 20px;
}

.login-link {
    margin-top: 20px;
    color: #777;
}

.login-link a {
    color: #28a745;
    text-decoration: none;
    font-weight: 500;
}

.login-link a:hover {
    text-decoration: underline;
}

.error-message {
    color: red;
    font-size: 0.8rem;
    margin-top: 5px;
}
</style>

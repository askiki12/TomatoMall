<script setup>
import { ref, onMounted, computed } from "vue";
import { getCart, updateCartItemQuantity, deleteCartItem } from "../api/cart";
import { getProductStockpile } from "../api/product";
import { ElMessage, ElEmpty, ElLoading } from "element-plus";
import PayOrderDialog from "../components/Tomato-Dialog/PayOrderDialog.vue";

const cartItems = ref([]); // 购物车商品列表
const loading = ref(true); // 是否正在加载中
const error = ref(null); // 错误信息
const totalAmount = ref(0); // 总金额
const dialogVisible = ref(false);
const selectedItems = ref([]); // 用于存储被选中的商品
const checkoutItems = ref([]); // 用于结算的商品列表
const checkoutIds = ref([]); // 用于存储结算商品的 ID

// 计算选中商品的总金额
const selectedTotalAmount = computed(() =>
    selectedItems.value.reduce(
        (total, item) => total + item.price * item.quantity,
        0
    )
);

// 获取购物车数据
const fetchCart = async () => {
    const loading = ElLoading.service({
        lock: true,
        text: "加载购物车中...",
        background: "rgba(0, 0, 0, 0.3)",
    });
    error.value = null;
    try {
        const response = await getCart();
        console.log("API Response:", response);
        console.log("response.data:", response.data);

        if (response.data) {
            cartItems.value = response.data.map((item) => ({
                ...item,
                selected: false,
            }));
            calculateTotal();
        } else {
            error.value = "从服务器收到了无效的购物车数据。";
            cartItems.value = [];
            calculateTotal();
        }
    } catch (err) {
        error.value = "获取购物车失败。请重试。";
        console.error(err);
    } finally {
        loading.close(); // 关闭加载动画
    }
};

// 更新购物车商品数量
const handleQuantityChange = async (item) => {
    try {
        // 获取商品库存信息
        const stockpileResponse = await getProductStockpile(item.productId);
        if (stockpileResponse.data) {
            const stockAmount =
                stockpileResponse.data.amount - stockpileResponse.data.frozen;
            // 判断修改后的数量是否大于库存
            if (item.quantity > stockAmount) {
                // 数量大于库存，给出提示
                ElMessage.error(
                    `商品 《${item.title}》 库存不足，当前可售库存为 ${stockAmount}`
                );
                // 还原数量为修改前的值
                item.quantity = stockAmount;
                return; // 停止后续操作
            }
            // 更新购物车商品数量
            await updateCartItemQuantity(item.cartItemId, {
                quantity: item.quantity,
            });
            calculateTotal();
        } else {
            // 获取库存信息失败
            ElMessage.error(`获取商品 ${item.title} 库存信息失败`);
        }
    } catch (err) {
        console.error("更新数量失败:", err);
        error.value = "更新数量失败。请重试。";
        ElMessage.error(error.value); // 显示错误信息
        await fetchCart();
    }
};

// 删除购物车商品
const removeItem = async (item) => {
    try {
        await deleteCartItem(item.cartItemId); // 调用 API 删除商品
        cartItems.value = cartItems.value.filter(
            (cartItem) => cartItem.cartItemId !== item.cartItemId
        ); // 从本地数组删除
        calculateTotal(); // 重新计算总价
    } catch (error) {
        console.error("删除商品失败:", error);
        error.value = "删除商品失败。请重试。"; // 设置错误信息
        await fetchCart(); // 重新获取购物车数据以确保数据正确
    }
};

// 计算总价
const calculateTotal = () => {
    totalAmount.value = cartItems.value.reduce(
        (total, item) => total + item.price * item.quantity,
        0
    ); // 计算总价
    console.log("总金额:", totalAmount.value);
};

// 结算按钮点击事件
const handleCheckout = () => {
    checkoutItems.value = selectedItems.value;
    checkoutIds.value = checkoutItems.value.map(
        (item) => item.cartItemId
    );
    console.log("要结算的商品:", checkoutItems.value);
    dialogVisible.value = true; // 显示 PayOrderDialog
    console.log("结算的商品id:", checkoutIds.value);
};

// 关闭 PayOrderDialog
const closeDialog = () => {
    dialogVisible.value = false;
};

// 更新选中的商品
const updateSelectedItems = (item) => {
    if (item.selected) {
        selectedItems.value.push(item);
    } else {
        const index = selectedItems.value.indexOf(item);
        if (index > -1) {
            selectedItems.value.splice(index, 1);
        }
    }
};

// 组件挂载后获取购物车数据
onMounted(fetchCart);
</script>

<template>
    <div class="page-container">
        <div class="cart-page">
            <div v-if="error">{{ error }}</div>
            <ElEmpty v-else-if="cartItems.length === 0" description="您的购物车是空的。" style="margin: auto;" />
            <div v-else class="cart-content">
                <div
                    v-for="item in cartItems"
                    :key="item.cartItemId"
                    class="cart-item"
                >
                    <el-checkbox
                        v-model="item.selected"
                        @change="updateSelectedItems(item)"
                    ></el-checkbox>
                    <div class="item-info">
                        <img
                            :src="item.cover"
                            alt="商品封面"
                            class="item-cover"
                        />
                        <div class="item-details">
                            <h3>{{ item.title }}</h3>
                            <p>{{ item.description }}</p>
                        </div>
                    </div>
                    <div class="item-actions">
                        <div class="price">￥{{ item.price }}</div>
                        <div class="quantity-control">
                            <el-input-number
                                v-model="item.quantity"
                                :min="1"
                                @change="handleQuantityChange(item)"
                            ></el-input-number>
                            <el-button @click="removeItem(item)" type="danger"
                                >移除</el-button
                            >
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bottom-checkout-bar">
            <div class="total-amount">
                <span class="total-label">合计:</span>
                ￥{{ selectedTotalAmount.toFixed(2) }}
            </div>
            <button
                @click="handleCheckout"
                class="checkout-button"
                :disabled="selectedItems.length === 0"
            >
                结算
            </button>
        </div>
        <PayOrderDialog
            :visible="dialogVisible"
            :amount="selectedTotalAmount"
            :checkoutIds="checkoutIds"
            @close="closeDialog"
        />
    </div>
</template>

<style scoped>
/* 最外层容器，负责整个页面的滚动 */
.page-container {
    position: fixed; /* 固定定位 */
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh; /* 占据整个视口高度 */
    overflow-y: scroll; /* 允许垂直滚动 */
    box-sizing: border-box; /* 确保 padding 不会增加容器的尺寸 */
    padding-top: 50px; /* 留出 header 的空间 */
}

.cart-page {
    width: 100%;
    min-height: calc(
        100vh - 60px - 50px
    ); /* 100vh - bottom-menu height - header height */
    padding: 40px 20px;
    background-color: #f8f9fa;
    display: flex;
    flex-direction: column;
    align-items: center;
    box-sizing: border-box;
}

.cart-content {
    width: 100%;
    max-width: 900px;
    flex-grow: 1;
}

.cart-item {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    border: 1px solid darkgray;
    border-radius: 10px;
    margin-bottom: 10px;
    padding: 10px;
    background-color: white;
    width: 100%;
}

.item-info {
    display: flex;
    align-items: center;
    margin-left: 0;
}

.item-cover {
    width: 100px;
    height: 150px;
    object-fit: cover;
    margin-right: 10px;
    margin-left: 0;
}

.item-details {
    flex: 1;
    margin: 10px;
}

.item-details h3 {
    font-size: 21px;
    font-weight: bold;
}

.item-actions {
    display: flex;
    align-items: center;
    margin-left: auto;
}

.price {
    margin-right: 20px;
    color: darkorange;
    font-weight: bold;
    font-size: 20px;
}

.quantity-control {
    display: flex;
    border-color: #2c3e50;
    align-items: center;
    color: #2c3e50;
}

.quantity-control button {
    padding: 5px 10px;
    margin: 0 5px;
    cursor: pointer;
}

.bottom-checkout-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #fff;
    padding: 10px 20px; /* 增加左右padding */
    box-shadow: 0px -2px 5px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: right; /* 修改: 金额和按钮左右对齐 */
    align-items: center;
    z-index: 100;
    box-sizing: border-box; /* 确保 padding 不会增加宽度 */
}

.total-amount {
    font-size: 1.5rem; /* 调整字体大小 */
    font-weight: bold;
    color: darkorange;
}

.total-label {
    font-size: 1.5rem; /* 调整字体大小 */
    font-weight: bold;
    color: #2c3e50;
}

.checkout-button {
    background-color: darkorange; /* 使用 Element UI 的主题色 */
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-left: 25px;
}

.checkout-button:hover {
    background-color: green; /* 鼠标悬停时的颜色 */
}

.checkout-button:disabled {
    background-color: #ccc;
    cursor: not-allowed;
}

h1 {
    margin-top: 30px;
}

.cart-item > .el-checkbox {
    margin-left: 10px;
    margin-right: 30px; /* 调整复选框和商品信息之间的距离 */
    transform: scale(1.5);
}
</style>

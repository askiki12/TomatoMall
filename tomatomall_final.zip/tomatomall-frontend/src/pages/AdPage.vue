<script setup lang="ts">
import { ref, onMounted } from "vue";
import { ElMessage } from "element-plus";
import { useRouter } from "vue-router";
import {
    Advertisement,
    getAdvertisements,
    updateAdvertisement as updateAdvertisementApi,
    deleteAdvertisement as deleteAdvertisementApi,
} from "../api/advertisement";
import EditAdDialog from "../components/Tomato-Dialog/EditAdDialog.vue";

const role = sessionStorage.getItem("role");
if (role !== "admin") {
    ElMessage.error("没有权限访问该页面。");
    setTimeout(() => {
        router.push("/home");
    }, 2000);
}

const router = useRouter();

const advertisements = ref<Advertisement[]>([]);

const editDialogVisible = ref(false);
const selectedAdvertisement = ref<Advertisement>({
    id: 0,
    title: "",
    content: "",
    imgUrl: "",
    productId: "",
});

const openEditDialog = (advertisement: Advertisement) => {
    selectedAdvertisement.value = advertisement;
    editDialogVisible.value = true;
};
const handleEditSubmit = (advertisement: Advertisement) => {
    updateAdvertisement(advertisement);
    editDialogVisible.value = false;
};

const fetchAdvertisements = async () => {
    try {
        const response = await getAdvertisements();
        if (response.code === "200") {
            advertisements.value = response.data;
        } else {
            ElMessage.error(response.msg || "获取广告列表失败。");
        }
    } catch (error) {
        console.error("Error fetching advertisements:", error);
        ElMessage.error("获取广告列表时发生错误。");
    }
};

const handleCreateAd = () => {
    router.push({
        path: "/warehouse",
        query: { from: "advertisement" } // 通过查询参数传递来源信息
    });
};

const updateAdvertisement = async (advertisement: Advertisement) => {
    try {
        const response = await updateAdvertisementApi({
            id: advertisement.id,
            title: advertisement.title,
            content: advertisement.content,
            imgUrl: advertisement.imgUrl,
            productId: advertisement.productId,
        });
        if (response.code === "200") {
            ElMessage.success("广告更新成功！");
            fetchAdvertisements();
        } else {
            ElMessage.error(response.msg || "更新广告失败。");
        }
    } catch (error) {
        console.error("Error updating advertisement:", error);
        ElMessage.error("更新广告时发生错误。");
    }
};

const deleteAdvertisement = async (id: number) => {
    try {
        const response = await deleteAdvertisementApi(id);
        if (response.code === "200") {
            advertisements.value = advertisements.value.filter(
                (advertisement) => advertisement.id !== id
            );
            ElMessage.success("广告删除成功！");
        } else {
            ElMessage.error(response.msg || "删除广告失败。");
        }
    } catch (error) {
        console.error("Error deleting advertisement:", error);
        ElMessage.error("删除广告时发生错误。");
    }
};

onMounted(async () => {
    await fetchAdvertisements();
});
</script>

<template>
    <div class="container">
        <div class="ad-edit-list" v-if="role === 'admin'">
            <div class="header">
                <h1>广告列表</h1>
                <el-button type="primary" @click="handleCreateAd" class="add-ad-button"
                    >添加广告</el-button
                >
            </div>
            <el-table
                :data="advertisements"
                style="width: 100%; text-align: center"
                border
            >
                <el-table-column prop="title" label="标题" align="center" />
                <el-table-column prop="content" label="内容" align="center" />
                <el-table-column label="图片" align="center">
                    <template #default="scope">
                        <img
                            :src="scope.row.imgUrl"
                            alt="广告图片"
                            style="
                                width: 80px;
                                height: 80px;
                                border-radius: 5px;
                                object-fit: cover;
                            "
                        />
                    </template>
                </el-table-column>
                <el-table-column label="操作" align="center">
                    <template #default="scope">
                        <el-button
                            type="text"
                            @click="openEditDialog(scope.row)"
                            >编辑</el-button
                        >
                        <el-button
                            type="text"
                            @click="deleteAdvertisement(scope.row.id)"
                            >删除</el-button
                        >
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <EditAdDialog
            v-model:visible="editDialogVisible"
            :advertisement="selectedAdvertisement"
            @submit="handleEditSubmit"
        />
    </div>
</template>

<style scoped>
.container {
    width: 100%;
    min-height: 100vh;
    padding: 40px 20px;
    background-color: #f8f9fa;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    box-sizing: border-box;
    height: 100vh;
    position: fixed;
    top: 50px;
    left: 0;
    overflow: auto;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.add-ad-button {
    margin-left: auto;
}

.ad-edit-list {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    background-color: white;
    border-radius: 16px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.ad-edit-list h1 {
    font-size: 2rem;
    color: #2c3e50;
    margin-bottom: 20px;
}

@media (max-width: 768px) {
    .container {
        padding: 20px 10px;
    }
}

.no-permission {
    color: red;
    font-weight: bold;
    font-size: 33px;
    text-align: center;
    width: 800px;
    margin-left: 100px;
}
</style>

<template>
    <div class="product-detail-container">
        <div v-if="error" class="error-message">错误: {{ error }}</div>
        <div v-if="product" class="product-detail-content-wrapper">
            <div class="product-detail">
                <h1 class="product-title">{{ product.title }}</h1>
                <div class="product-detail-header">
                    <div class="product-image-container">
                        <img
                            :src="product.cover || '/src/assets/default-avatar.png'"
                            :alt="product.title"
                            class="product-image"
                        />
                    </div>
                    <div class="product-info">
                        <div
                            v-if="
                                product.specifications &&
                                product.specifications.length > 0
                            "
                            class="product-specifications"
                        >
                            <ul>
                                <li
                                    v-for="spec in product.specifications"
                                    :key="spec.id"
                                >
                                    {{ spec.item }}:
                                    {{ spec.value }}
                                </li>
                            </ul>
                        </div>

                        <p class="product-price">价格: ￥{{ product.price }}</p>
                    </div>
                    <div class="product-rating">
                        <h2>番茄评分</h2>
                        <span style="font-size: 4rem">{{
                            product.rate.toPrecision(2)
                        }}</span>
                    </div>
                </div>
                <div class="product-actions">
                    <!-- User Rating Section -->
                    <div class="submit-rating-section">
                        <div class="rating-title">我的评分:</div>
                        <el-rate
                            v-model="userRating"
                            :colors="['#99A9BF', '#F7BA2A', '#FF9900']"
                            @change="submitRating"
                            style="margin-left: 10px"
                        />
                        <el-button
                            v-if="currentMark"
                            type="danger"
                            @click="deleteRating"
                            style="margin-top: 10px; margin-left: 10px"
                            >删除评分</el-button
                        >
                    </div>

                    <p class="product-description">
                        {{ product.description }}
                    </p>

                    <div class="product-detail-text">
                        <h2>商品详情</h2>
                        <p>{{ product.detail }}</p>
                    </div>
                    <!-- Stockpile Information Display -->
                    <div v-if="stockpileError" class="error-message">
                        库存错误: {{ stockpileError }}
                    </div>

                    <div v-if="stockpileData" class="stockpile-info">
                        <h2>库存信息</h2>
                        <p>
                            可售库存:
                            {{ stockpileData.amount - stockpileData.frozen }}
                        </p>
                    </div>
                </div>
            </div>

            <!-- Comments Section Integration -->
            <div class="comments-section-wrapper">
                <CommentsComponent :product-id="product.id" />
            </div>
        </div>
        <AddToCartBar
            v-if="product"
            :product-id="product.id"
            @cart-item-added="handleCartItemAdded"
            class="add-to-cart-bar-fixed"
        />
        <!-- Show "Product not found" or other states if product is null and not loading -->
        <div
            v-if="!product && !loadingInitial && !error"
            class="no-product-found"
        >
            <el-empty description="商品未找到或已下架" />
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import {
    getProductById,
    getProductStockpile,
    getProductMark,
    createProductMark,
    changeProductMark,
    deleteProductMark,
} from "../api/product";
import AddToCartBar from "../components/AddToCartBar.vue";
import CommentsComponent from "../components/comments.vue";
import { ElEmpty, ElMessage } from "element-plus";

interface ProductSpecification {
    id: string | number;
    item: string;
    value: string;
    productId: string | number;
}

interface Product {
    id: number;
    title: string;
    price: number;
    rate: number;
    description: string;
    cover: string;
    detail: string;
    specifications: ProductSpecification[];
}

interface StockpileData {
    id: string;
    amount: number;
    frozen: number;
    productId: string;
}

const route = useRoute();
const productIdFromRoute = ref<number | null>(null); // Renamed to avoid conflict if you use productId elsewhere
const product = ref<Product | null>(null);
const error = ref<string | null>(null);
const loadingInitial = ref(true); // For initial page load

const stockpileData = ref<StockpileData | null>(null);
const stockpileLoading = ref(false); // Kept for potential separate loading indicators if needed
const stockpileError = ref<string | null>(null);

const userRating = ref<number | undefined>(undefined); // 用户选择的评分
const currentMark = ref<string | null>(null); // 当前评分

async function fetchStockpile(pId: number) {
    stockpileLoading.value = true;
    stockpileError.value = null;
    try {
        const stockpileResponse = await getProductStockpile(pId);
        if (stockpileResponse.code === "200") {
            stockpileData.value = stockpileResponse.data;
        } else if (stockpileResponse.code === "400") {
            stockpileError.value = stockpileResponse.msg || "库存信息未找到。";
        } else {
            stockpileError.value =
                stockpileResponse.msg || "获取库存信息失败。";
        }
    } catch (stockpileErr: any) {
        stockpileError.value =
            stockpileErr.message || "获取库存信息时发生了一个意外错误。";
    } finally {
        stockpileLoading.value = false;
    }
}

onMounted(async () => {
    productIdFromRoute.value = Number(route.params.id);
    if (!productIdFromRoute.value || isNaN(productIdFromRoute.value)) {
        error.value = "无效的商品ID。";
        loadingInitial.value = false;
        return;
    }

    loadingInitial.value = true;
    error.value = null;

    try {
        const response = await getProductMark(productIdFromRoute.value);
        console.log("获取评分响应:", response);
        if (response.code === "200" && response.data) {
            if (response.data === "0.0") {
                currentMark.value = null; // 没有评分
                userRating.value = undefined; // 清空评分
            } else {
                // 解析评分数据
                currentMark.value = response.data;
                userRating.value = Number(response.data); // 设置初始评分
            }
        } else {
            currentMark.value = null; // 没有评分
        }
    } catch (err: any) {
        console.error("获取评分失败:", err);
        currentMark.value = null; // 重置评分
    }

    try {
        const response = await getProductById(productIdFromRoute.value);
        if (response.code === "200" && response.data) {
            product.value = response.data;
            // Fetch stockpile after product details are loaded
            await fetchStockpile(productIdFromRoute.value);
        } else if (response.code === "400") {
            error.value = response.msg || "商品不存在。";
            product.value = null; // Ensure product is null if not found
        } else {
            error.value = response.msg || "获取商品详情失败。";
            product.value = null;
        }
    } catch (e: any) {
        error.value = e.message || "发生了一个意外错误。";
        product.value = null;
    } finally {
        loadingInitial.value = false;
    }
});

const handleCartItemAdded = (cartItem: any) => {
    console.log("Item added to cart from detail page:", cartItem);
    // Potentially show a success message
    ElMessage.success("商品已添加到购物车！");
};

const submitRating = async () => {
    if (userRating.value === undefined) {
        ElMessage.error("请选择一个评分！");
        return;
    }

    if (!product.value) {
        ElMessage.error("商品信息未加载完成！");
        return;
    }

    try {
        // 检查是否已有评分
        if (currentMark.value) {
            // 修改现有评分
            const response = await changeProductMark({
                productId: product.value.id,
                markStar: userRating.value - 1,
            });
            if (response.code === "200") {
                ElMessage.success(response.data || "评分更新成功！");
                window.location.reload();
            } else {
                ElMessage.error(response.data || "更新评分失败");
            }
        } else {
            // 创建新评分
            const response = await createProductMark({
                productId: product.value.id,
                markStar: userRating.value - 1,
            });
            if (response.code === "200") {
                currentMark.value = response.data;
                ElMessage.success("评分提交成功！");
                window.location.reload();
            } else {
                ElMessage.error(response.msg || "提交评分失败");
            }
        }
    } catch (err: any) {
        ElMessage.error(err.message || "提交评分时发生了一个意外错误。");
    }
};

const deleteRating = async () => {
    if (!product.value) {
        ElMessage.error("商品信息未加载完成！");
        return;
    }

    try {
        const response = await deleteProductMark(product.value.id);
        if (response.code === "200") {
            currentMark.value = null;
            userRating.value = undefined; // 清空评分
            ElMessage.success("评分删除成功！");
        } else {
            ElMessage.error(response.msg || "删除评分失败");
        }
    } catch (err: any) {
        ElMessage.error(err.message || "删除评分时发生了一个意外错误。");
    }
};
</script>

<style scoped>
.product-detail-container {
    display: flex;
    justify-content: center;
    align-items: self-start;
    min-height: 100vh;
    background-color: #f0f2f5;
    padding: 0 2.0%;
    width: 100vw;
    height: 100vh;
    overflow: scroll;
    position: fixed;
    top: 60px;
    left: 0;
}

/* 产品详情容器 */
.product-detail-content-wrapper {
    max-width: 1200px; /* 最大宽度 */
    display: flex;
    flex-wrap: wrap; /* 允许换行 */
    justify-content: center; /* 子元素居中 */
    gap: 20px; /* 子元素之间的间隔 */
}

/* 产品图片和信息 */
.product-detail {
    display: flex;
    flex-direction: column; /* 垂直排列 */
    align-items: start; /* 居中对齐 */
    width: 100%; /* 占满容器宽度 */
    max-width: 1200px; /* 最大宽度 */
    height: 80%;
    margin-top: 20px;
    margin-bottom: 20px;
    padding: 3%;
    background: #ffffff; /* 白色背景 */
    border-radius: 8px; /* 圆角 */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* 阴影效果 */
    row-gap: 5%; /* 子元素之间的间隔 */
}

.product-detail-header {
    display: flex;
    flex-direction: row; /* 水平排列 */
    align-items: flex-start; /* 顶部对齐 */
    width: 100%; /* 占满容器宽度 */
    margin-bottom: 20px; /* 底部间距 */
    row-gap: 10%;
}

.product-image-container {
    padding: 1.5%;
    width: 20%; /* 图片容器的宽度 */
    margin-right: 20px;
    flex-shrink: 0; /* 防止缩小 */
    display: flex;
    border-radius: 8px; /* 圆角 */
}

.product-image {
    width: 100%;
    height: auto;
    border-radius: 8px;
    background: #f5f5f5;
    object-fit: cover; /* 确保图片填充整个容器 */
}

.product-info {
    min-width: 50%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex: 1;
    padding: 1.5%;
}

.product-actions {
    width: 100%;
    flex-direction: column; /* 垂直排列 */
    display: flex;
    gap: 5%;;
}

.submit-rating-section {
    display: flex;
    flex-direction: row; /* 垂直排列 */
    align-items: center; /* 垂直居中 */
    margin-bottom: 1.5%;
}

/* 产品标题 */
.product-title {
    font-size: 2rem;
    color: #2c3e50;
    margin-bottom: 10px;
    font-weight: bold;
}

/* 产品价格 */
.product-price {
    font-size: 1.5rem;
    color: #28a745;
    font-weight: bold;
    margin: 10px 0;
}

/* 产品评分 */
.product-rating {
    font-size: 1.5rem;
    color: #f39c12;
    margin-bottom: 10px;
    font-weight: bold;
    padding: 2.5%;
    text-align: center;
}

/* 产品描述 */
.product-description {
    font-size: 1rem;
    color: #555;
    line-height: 1.5;
    margin-bottom: 10px;
    flex-direction: row;
    flex-wrap: wrap;
}

/* 商品规格 */
.product-specifications ul {
    list-style: none;
    padding: 0;
    margin-bottom: 0.5%;
}

.product-specifications li {
    font-size: 1.5rem;
    position: relative;
}

/* 商品详情 */
.product-detail-text p {
    font-size: 1rem;
    color: #555;
    line-height: 1.5;
    margin-bottom: 10px;
}

/* 错误信息 */
.error-message {
    color: #c0392b;
    padding: 15px;
    background: #fdecea;
    border: 1px solid #f5c6cb;
    border-radius: 8px;
    margin: 20px auto;
    max-width: 800px;
    width: 100%;
    text-align: center;
}

/* 库存信息 */
.stockpile-info p {
    font-size: 1.0rem;
}

/* 评论区域 */
.comments-section-wrapper {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    margin-bottom: 130px;
}

/* 没有找到产品的提示 */
.no-product-found {
    margin-top: 50px;
    text-align: center;
    width: 100%;
}
</style>
/* 宽屏优化 */ @media (min-width: 1200px) { .product-detail-container {
justify-content: center; /* 居中对齐 */ width: 100%; /* 宽度占满容器 */
min-width: 1200px; /* 最小宽度 */ margin-top: 4%; margin-bottom: 3%; }
.product-detail-content-wrapper { display: flex; /* 使用flex布局 */
justify-content: space-between; /* 左右对齐 */ width: 100%; /* 宽度占满容器 */
margin: auto; } .product-detail { display: flex; /* 使用flex布局 */
flex-direction: row; /* 水平排列 */ align-items: flex-start; /* 对齐方式 */
flex: 1; /* 占据一半宽度 */ margin-right: 20px; /* 右边距 */ }
.product-image-container { width: 30%; /* 图片容器宽度 */ margin-right: 20px; /*
图片与文字的间隔 */ } .product-info { flex: 1; /* 文字内容占据剩余空间 */
display: flex; flex-direction: column; } .comments-section-wrapper { flex: 1; /*
评论区域占据一半宽度 */ margin-left: 20px; /* 左边距 */ } }

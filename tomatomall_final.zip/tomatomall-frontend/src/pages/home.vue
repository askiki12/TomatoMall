<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRouter } from "vue-router";
import { getProductList } from "../api/product";
import { getAdvertisements, Advertisement } from "../api/advertisement";
import { ElLoading, ElEmpty } from "element-plus";
import { StarFilled } from "@element-plus/icons-vue";

interface Product {
    id: number;
    title: string;
    price: number;
    rate: number;
    description: string;
    cover: string;
    detail: string;
    specifications: any[];
}

const products = ref<Product[]>([]);
const advertisements = ref<Advertisement[]>([]);
const combinedItems = ref<(Product | Advertisement)[]>([]);
const error = ref<string | null>(null);

const router = useRouter();

// 获取商品数据
const fetchProducts = async () => {
    try {
        const response = await getProductList();
        if (response.code === "200") {
            return response.data;
        } else {
            throw new Error(response.msg || "获取商品列表失败");
        }
    } catch (e: any) {
        error.value = e.message || "发生了一个意外错误";
        return [];
    }
};

// 获取广告数据
const fetchAdvertisements = async () => {
    try {
        const response = await getAdvertisements();
        if (response.code === "200") {
            return response.data;
        } else {
            console.warn("获取广告失败:", response.msg);
            return [];
        }
    } catch (e: any) {
        console.error("获取广告时发生错误:", e);
        return [];
    }
};

// 合并商品和广告
const combineProductsAndAds = () => {
    const productCopy = [...products.value];
    const adCopy = [...advertisements.value];
    const combined: (Product | Advertisement)[] = [];

    let productIndex = 0;
    let adIndex = 0;

    while (productIndex < productCopy.length || adIndex < adCopy.length) {
        if (productIndex < productCopy.length && Math.random() > 0.3) {
            combined.push(productCopy[productIndex]);
            productIndex++;
        } else if (adIndex < adCopy.length) {
            combined.push(adCopy[adIndex]);
            adIndex++;
        }
    }

    combinedItems.value = combined;
};

// 跳转到商品或广告详情
const goToProductDetail = (item: Product | Advertisement) => {
    if ("productId" in item) {
        router.push(`/product/${item.productId}`);
    } else {
        router.push(`/product/${item.id}`);
    }
};

// 判断是否为广告
const isAdvertisement = (
    item: Product | Advertisement
): item is Advertisement => {
    return "productId" in item && item.productId !== undefined;
};

// 页面加载时获取数据
onMounted(async () => {
    error.value = null;

    const loading = ElLoading.service({
        lock: true,
        text: "加载商品中...",
        background: "rgba(0, 0, 0, 0.3)",
    });

    try {
        const [productsData, advertisementsData] = await Promise.all([
            fetchProducts(),
            fetchAdvertisements(),
        ]);

        products.value = productsData;
        advertisements.value = advertisementsData;
        combineProductsAndAds();
    } catch (e: any) {
        error.value = e.message || "发生了一个意外错误";
    } finally {
        loading.close();
    }
});
</script>

<template>
    <div class="container">
        <div v-if="combinedItems.length > 0" class="product-list">
            <div
                v-for="item in combinedItems"
                :key="
                    isAdvertisement(item)
                        ? 'ad-' + item.id
                        : 'product-' + item.id
                "
                class="product-item"
                :class="{ 'advertisement-item': isAdvertisement(item) }"
                @click="goToProductDetail(item)"
            >
                <img
                    :src="
                        isAdvertisement(item)
                            ? item.imgUrl
                            : item.cover || '/src/assets/default-avatar.png'
                    "
                    :alt="item.title"
                    class="product-image"
                />
                <div class="product-header">
                    <h2 class="product-title">{{ item.title }}</h2>
                    <div v-if="!isAdvertisement(item)" class="product-rating">
                        <el-icon style="top: 3px"><StarFilled /></el-icon>
                        {{ item.rate.toPrecision(2) }}
                    </div>
                </div>
                <p class="product-description">
                    {{
                        isAdvertisement(item) ? item.content : item.description
                    }}
                </p>
                <p v-if="!isAdvertisement(item)" class="product-price">
                    价格: ${{ item.price }}
                </p>
                <p v-else>广告</p>
            </div>
        </div>

        <ElEmpty v-else description="未找到商品和广告。" style="margin: auto" />
    </div>
</template>

<style scoped>
.container {
    display: flex;
    justify-content: center;
    align-items: self-start;
    background-color: #f0f2f5;
    width: 100vw;
    height: 93vh;
    overflow-y: scroll;
    position: fixed;
    top: 60px;
    left: 0;
}

.product-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 50px;
    margin: 0 auto;
    width: 70%;
    padding: 20px;
}

.product-item {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    overflow: hidden;
    cursor: pointer;
}

.product-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
}

.product-header {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    justify-content: space-between;
}

.product-image {
    width: 100%;
    object-fit: contain;
    margin-bottom: 15px;
    border-radius: 8px;
    background: #f5f5f5;
}

.product-title {
    font-size: 1.8rem;
    color: #2c3e50;
    margin-bottom: 12px;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    font-weight: bold;
}

.product-price {
    font-size: 1rem;
    color: green;
    font-weight: 700;
    margin: 8px 0;
}

.product-rating {
    font-size: 1.5rem;
    font-weight: 700;
    color: #f39c12;
}

.product-description {
    font-size: 1rem;
    color: #555;
    line-height: 1.5;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.loading-message,
.no-products {
    font-size: 1.2rem;
    color: #7f8c8d;
    text-align: center;
    padding: 40px 0;
}

.error-message {
    color: #c0392b;
    padding: 20px;
    background: #f9ebeb;
    border-radius: 8px;
    margin: 20px auto;
    max-width: 600px;
}

@media (max-width: 768px) {
    .container {
        padding: 20px 10px;
    }

    .product-list {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .product-image {
        height: 180px;
    }
}

@media (min-width: 1600px) {
    .product-list {
        max-width: 1800px;
    }
}

.advertisement-item {
    background-color: #f0f8ff;
    border: 1px solid #ddd;
}

.advertisement-item .product-title {
    color: #007bff;
    font-style: italic;
}

.advertisement-item .product-description {
    font-size: 1.2rem;
}

.advertisement-item .product-image {
    object-fit: contain;
    width: 100%;
    border-radius: 8px;
}
</style>

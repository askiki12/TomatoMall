<script setup lang="ts">
import { ref, onMounted } from "vue";
import { getUserDetail, updateUserInfo } from "../api/user";
import { uploadImage } from "../api/tools";
import { ElMessage, ElLoading } from "element-plus";
import { Delete } from "@element-plus/icons-vue";
import { useRouter } from "vue-router";

// 从sessionStorage获取用户名
const username = sessionStorage.getItem("username") || "";
const router = useRouter();
// 用户详情接口类型
interface UserDetails {
    avatar?: string;
    role?: string;
    name?: string;
    email?: string;
    location?: string;
    telephone?: string; // 添加电话号码字段
    id?: string;
    [key: string]: any; // 允许其他字段
}

// 定义响应式变量
const userDetails = ref<UserDetails | null>(null); // 用户详情
const fileInputRef = ref<HTMLInputElement | null>(null); // 文件输入框引用
const avatarUrl = ref(""); // 头像URL
const avatarUploadError = ref(""); // 头像上传错误信息
const name = ref(""); // 姓名
const id = ref(""); // 用户ID
const email = ref(""); // 邮箱
const location = ref(""); // 地址
const telephone = ref(""); // 电话号码
const password = ref(""); // 密码
const confirmPassword = ref(""); // 确认密码
const validatePhone = (phone: any) => /^1[3-9]\d{9}$/.test(phone);
const validateEmail = (email: any) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

// 点击头像时触发文件输入框
const handleAvatarClick = () => {
    fileInputRef.value?.click();
};

// 验证上传的头像文件
const beforeAvatarUpload = (file: File) => {
    const isImage = ["image/jpeg", "image/png", "image/gif"].includes(
        file.type
    );
    const isLt2M = file.size / 1024 / 1024 < 2;

    if (!isImage) {
        ElMessage.error("上传头像只能是 JPG/PNG/GIF 格式!");
        return false;
    }
    if (!isLt2M) {
        ElMessage.error("上传头像大小不能超过 2MB!");
        return false;
    }
    return true;
};

// 删除头像
const handleAvatarRemove = async () => {
    try {
        const payload = {
            username,
            avatar: "", // 设置头像为空
        };
        const response = await updateUserInfo(payload);
        if (response.code === "200") {
            avatarUrl.value = ""; // 清空头像URL
            if (userDetails.value) {
                userDetails.value.avatar = ""; // 更新用户详情中的头像
            }
            fileInputRef.value!.value = ""; // 清空文件输入框
            ElMessage.success("头像已删除");
        } else {
            throw new Error(response.msg || "Unknown error");
        }
    } catch (error: any) {
        ElMessage.error(`删除头像失败: ${error.message}`);
    }
};

// 处理文件上传
const handleFileChange = async () => {
    console.log("File input changed");
    const fileInput = fileInputRef.value;
    const file = fileInput?.files?.[0];
    if (!file) {
        ElMessage.error("请选择要上传的头像文件");
        return;
    }

    if (!beforeAvatarUpload(file)) {
        return; // 如果验证失败，直接返回
    }

    const loading = ElMessage({
        message: "头像上传中...",
        type: "info",
        duration: 0,
        showClose: true,
    });

    try {
        const formData = new FormData();
        formData.append("file", file);

        const res = await uploadImage(formData);

        if (res.data.code === "200") {
            avatarUrl.value = res.data.data; // 更新头像URL
            if (userDetails.value) {
                userDetails.value.avatar = res.data.data; // 更新用户详情中的头像
            }

            // 更新后端用户信息
            const payload = {
                username,
                avatar: res.data.data, // 上传后的头像URL
            };
            const updateResponse = await updateUserInfo(payload);
            if (updateResponse.code !== "200") {
                throw new Error(updateResponse.msg || "Unknown error");
            }

            ElMessage.success("头像上传成功");
        } else {
            throw new Error(res.data.msg || "Unknown error");
        }
    } catch (error: any) {
        avatarUploadError.value = `头像上传失败: ${error.message}`;
        ElMessage.error(avatarUploadError.value);
    } finally {
        loading.close();
    }
};

const validatePassword = (password: string) => {
    // 密码不能为空
    if (!password) {
        return "密码不能为空";
    }
    // 可选：密码长度至少为6位
    if (password.length < 6) {
        return "密码长度至少为6位";
    }
    // 可选：密码必须包含字母和数字
    // if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
    //     return "密码必须包含字母和数字";
    // }
    return "";
};

// 提取验证逻辑到单独的函数
const validateProfile = () => {
    if (!userDetails.value) {
        ElMessage.error("用户信息未加载");
        return false;
    }

    if (!name.value) {
        ElMessage.error("姓名不能为空");
        return false;
    }

    if (email.value && !validateEmail(email.value)) {
        ElMessage.error("邮箱格式不正确");
        return false;
    }

    if (telephone.value && !validatePhone(telephone.value)) {
        ElMessage.error("电话号码格式不正确");
        return false;
    }

    if (password.value) {
        const passwordError = validatePassword(password.value);
        if (passwordError) {
            ElMessage.error(passwordError);
            return false;
        }

        if (password.value !== confirmPassword.value) {
            ElMessage.error("密码和确认密码不一致");
            return false;
        }
    }

    return true;
};

// 主函数中调用验证逻辑
const updateProfile = async () => {
    if (!validateProfile()) {
        return;
    }

    const payload = {
        username,
        name: name.value,
        email: email.value || undefined,
        location: location.value || undefined,
        telephone: telephone.value || undefined,
        password: password.value || undefined,
    };

    try {
        const response = await updateUserInfo(payload);
        if (response.code === "200") {
            if (userDetails.value) {
                userDetails.value.name = name.value;
                userDetails.value.email = email.value;
                userDetails.value.location = location.value;
                userDetails.value.telephone = telephone.value;
            }
            ElMessage.success("个人信息更新成功");
            if (fileInputRef.value) {
                fileInputRef.value.value = "";
            }
            if (password.value) {
                password.value = "";
                confirmPassword.value = "";
                router.push("/login");
                ElMessage.success("密码修改成功，请重新登录");
            }
        } else {
            throw new Error(response.msg || "Unknown error");
        }
    } catch (error: any) {
        ElMessage.error(`更新失败: ${error.message}`);
    }
};

// 获取用户详情
const fetchUserDetails = async () => {
    const loading = ElLoading.service({
        lock: true,
        text: "加载中...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.3)",
    });
    try {
        const response = await getUserDetail(username);
        console.log("User details response:", response);
        if (response.code === "200") {
            // 转换 id 类型
            const userData = {
                ...response.data,
                id: String(response.data.id), // 将 number 转换为 string
            };
            userDetails.value = userData;
            avatarUrl.value = userDetails.value.avatar || ""; // 初始化头像URL
            name.value = userDetails.value.name || "";
            email.value = userDetails.value.email || "";
            location.value = userDetails.value.location || "";
            telephone.value = userDetails.value.telephone || "";
            id.value = userDetails.value.id || "";
        } else {
            throw new Error("Failed to fetch user details");
        }
    } catch (error: any) {
        ElMessage.error(`获取用户信息失败: ${error.message}`);
        console.error("Error fetching user details:", error);
    } finally {
        loading.close(); // 关闭加载状态
    }
};
// 页面加载时获取用户详情
onMounted(fetchUserDetails);
</script>

<template>
    <div class="profile-container">
        <div class="profile-box">
            <h1>个人信息</h1>
            <div class="user-info-header">
                <div class="user-avatar">
                    <el-avatar
                        :src="
                            userDetails?.avatar ||
                            '/src/assets/default-avatar.png'
                        "
                        :size="150"
                        @click="handleAvatarClick"
                        class="avatar"
                    />
                    <el-icon
                        v-if="userDetails?.avatar"
                        @click="handleAvatarRemove"
                        type="danger"
                        class="avatar-remove-button"
                        circle
                        :size="24"
                    >
                        <Delete
                    /></el-icon>
                </div>
                <div class="user-details">
                    <p style="font-size: 2.5rem">{{ username }}</p>
                    <p>用户身份: {{ userDetails?.role }}</p>
                </div>
            </div>
            <el-divider />
            <div class="user-info-body">
                <el-form label-width="100px">
                    <el-form-item label="姓名:">
                        <el-input
                            v-model="name"
                            placeholder="请输入姓名"
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="邮箱:">
                        <el-input
                            v-model="email"
                            placeholder="请输入邮箱"
                            type="email"
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="地址:">
                        <el-input
                            v-model="location"
                            placeholder="请输入地址"
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="电话:">
                        <el-input
                            v-model="telephone"
                            placeholder="请输入电话"
                            type="tel"
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="密码:">
                        <el-input
                            v-model="password"
                            placeholder="请输入密码（至少6位）"
                            type="password"
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="确认密码:">
                        <el-input
                            v-model="confirmPassword"
                            placeholder="请确认密码"
                            type="password"
                        ></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <el-row class="update-button-row">
                <el-col :span="24">
                    <el-button
                        type="success"
                        @click="updateProfile"
                        class="update-button"
                        >更新信息</el-button
                    >
                </el-col>
            </el-row>
        </div>
        <input
            type="file"
            ref="fileInputRef"
            accept="image/*"
            @change="handleFileChange"
            style="display: none"
        />
    </div>
</template>

<style scoped>
.profile-container {
    display: flex;
    justify-content: center;
    align-items: self-start;
    min-height: 100vh;
    background-color: #f0f2f5;
    padding: 0;
    width: 100vw;
    height: 100vh;
    overflow: scroll;
    position: fixed;
    top: 60px;
    left: 0;
}

.profile-box {
    max-width: 700px;
    padding: 30px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
    margin-top: 2.5%;
}

.profile-box h1 {
    margin-bottom: 30px;
    color: #333;
    font-size: 2rem;
}

.user-info-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.user-avatar {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.user-avatar .avatar {
    cursor: pointer;
}

.user-avatar .avatar-remove-button {
    position: absolute;
    top: 0;
    right: 0;
    padding: 0;
    width: 24px;
    height: 24px;
    font-size: 14px;
    line-height: 24px;
    text-align: center;
    cursor: pointer;
}

.user-details {
    display: flex;
    flex-direction: column;
    margin-left: 22px;
}

.user-details p {
    font-size: 1.5rem;
    color: #555;
    font-weight: bold;
    text-align: center;
    margin-bottom: 10px;
}

.user-info-body {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.el-form-item {
    margin-bottom: 10px;
}

.update-button-row {
    display: flex;
    justify-content: flex-end;
    margin-top: 20px;
}

.update-button {
    margin-right: 0;
}
</style>

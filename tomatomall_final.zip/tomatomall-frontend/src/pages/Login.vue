<script setup>
import { reactive, computed } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import { login as loginApi, getUserDetail } from "../api/user"; // 导入登录 API

const state = reactive({
    username: "",
    password: "",
});

const router = useRouter();

// 计算属性，判断是否禁用登录按钮
const isLoginDisabled = computed(() => {
    return !state.username || !state.password;
});

const fetchUserRole = async () => {
    try {
        const response = await getUserDetail(
            sessionStorage.getItem("username") || ""
        );
        if (response.code === "200") {
            sessionStorage.setItem("role", response.data.role);
        } else {
            error.value = response.msg || "获取用户信息失败。";
        }
    } catch (e) {
        error.value = e.message || "发生了一个意外错误。";
    }
};

const login = async () => {
    try {
        const payload = {
            username: state.username,
            password: state.password,
        };

        const response = await loginApi(payload);

        // 登录成功
        if (response) {
            const token = response; // response 已经是 token
            sessionStorage.setItem("token", token); // 将 token 存储到 sessionStorage
            sessionStorage.setItem("username", state.username); // 存储用户名
            fetchUserRole(); // 获取用户角色
            ElMessage.success("登录成功");
            // 登录成功后，跳转到首页
            await router.push("/home");
        } else {
            ElMessage.error("密码错误或账号不存在，登录失败");
        }
    } catch (error) {
        console.error("登录失败，登录异常:", error);
        ElMessage.error("登录失败，登录异常");
    }
};
</script>

<template>
    <div class="login-container">
        <div class="login-box">
            <h1>欢迎登录</h1>
            <div class="input-group">
                <label for="username">用户名</label>
                <input
                    type="text"
                    id="username"
                    v-model="state.username"
                    placeholder="请输入用户名"
                    @keyup.enter="login"
                />
            </div>
            <div class="input-group">
                <label for="password">密码</label>
                <input
                    type="password"
                    id="password"
                    v-model="state.password"
                    placeholder="请输入密码"
                    @keyup.enter="login"
                />
            </div>
            <button
                @click="login"
                class="login-button"
                :disabled="isLoginDisabled"
            >
                登录
            </button>
            <p class="register-link">
                没有账号？ <router-link to="/register">立即注册</router-link>
            </p>
        </div>
    </div>
</template>

<style scoped>
/* 登录容器 */
.login-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh; /* 确保容器至少占满整个屏幕高度 */
    background-color: #f0f2f5; /* 轻微的背景色 */
    padding: 0; /* 移除 padding */
    width: 100vw; /* 使用 100vw 确保占据整个视口宽度 */
    height: 100vh; /* 确保占据整个视口高度 */
    overflow: hidden; /* 阻止可能的滚动条 */
    position: fixed; /* 确保 fixed 定位，不会被其他元素影响 */
    top: 0;
    left: 0;
}

/* 登录框 */
.login-box {
    width: 100%;
    max-width: 600px; /* 恢复到更合理的 max-width */
    padding: 30px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* 轻微的阴影 */
    text-align: center;
}

.login-box h1 {
    margin-bottom: 30px;
    color: #333;
    font-size: 2rem;
}

/* 输入框组 */
.input-group {
    margin-bottom: 20px;
    text-align: left;
}

.input-group label {
    display: block;
    margin-bottom: 8px;
    color: #555;
    font-weight: bold;
}

.input-group input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 1rem;
    transition: border-color 0.2s;
}

.input-group input:focus {
    border-color: #007bff; /* 输入框获取焦点时的边框颜色 */
    outline: none; /* 移除默认的 focus 样式 */
}

/* 登录按钮 */
.login-button {
    width: 100%;
    padding: 12px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    font-size: 1.1rem;
    cursor: pointer;
    transition: background-color 0.2s;
}

.login-button:disabled {
    background-color: #ccc; /* 禁用时的背景颜色 */
    cursor: not-allowed; /* 禁用时的鼠标样式 */
}

.login-button:hover {
    background-color: #0056b3; /* 鼠标悬停时的背景颜色 */
}

/* 注册链接 */
.register-link {
    margin-top: 20px;
    color: #777;
}

.register-link a {
    color: #007bff;
    text-decoration: none;
}

.register-link a:hover {
    text-decoration: underline;
}
</style>

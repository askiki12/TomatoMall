<template>
  <NavigationBar v-if="showNavigationBar" />
  <router-view />
</template>

<script setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import NavigationBar from './components/NavigationBar.vue'; // 确保路径正确

const route = useRoute();

const showNavigationBar = computed(() => {
  return route.name !== 'login' && route.name !== 'register';
});
</script>
import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { ElNotification } from 'element-plus';

// 创建 Axios 实例
const service: AxiosInstance = axios.create({
    baseURL: 'http://localhost:8080/api', // 后端 API 的基础 URL
    timeout: 5000,    // 请求超时时间，单位毫秒
});

// 请求拦截器
service.interceptors.request.use(
    config => {
        // 模拟网络延迟
        return new Promise((resolve) => {
            setTimeout(() => {
                // 添加 token 到请求头
                const token = sessionStorage.getItem('token');
                if (token) {
                    config.headers['token'] = token;
                }
                resolve(config);
            }, 100); // 延迟 1000 毫秒
        });
    },
    (error) => {
        console.log(error);
        return Promise.reject(error instanceof Error ? error : new Error(error?.message || 'Unknown error'));
    }
);

// 响应拦截器
service.interceptors.response.use(
    (response: AxiosResponse) => {
        return response;
    },
    (error) => {
        console.log(error);

        // 处理 401 错误
        if (error.response && error.response.status === 401) {
            console.warn('Unauthorized: Redirecting to login');
            sessionStorage.removeItem('token');
            // 可以使用 router.push('/login') 跳转，需要引入 Vue Router
            // router.push('/login');
        }

        // 根据错误状态码显示不同的提示
        if (error.response) {
            switch (error.response.status) {
                case 400:
                    ElNotification.error({
                        title: 'Error',
                        message: 'Bad Request: ' + error.response.data.message,
                        duration: 3000,
                    });
                    break;
                case 500:
                    ElNotification.error({
                        title: 'Error',
                        message: 'Internal Server Error',
                        duration: 3000,
                    });
                    break;
                default:
                    ElNotification.error({
                        title: 'Error',
                        message: error.message || 'An error occurred',
                        duration: 3000,
                    });
            }
        } else {
            ElNotification.error({
                title: 'Error',
                message: error.message || 'Network Error',
                duration: 3000,
            });
        }

        return Promise.reject(error instanceof Error ? error : new Error(error?.message || 'Unknown error')); // 继续 reject 错误，让组件处理
    }
);

export { service as axios }; // 导出 axios 实例
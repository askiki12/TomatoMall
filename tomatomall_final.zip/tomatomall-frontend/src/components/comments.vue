<template>
  <div class="comments-container">
    <h2>用户评论</h2>

    <!-- Add Comment Form -->
    <div class="add-comment-form">
      <el-input
          v-model="newCommentContent"
          type="textarea"
          :rows="3"
          placeholder="留下你的评论..."
          maxlength="500"
          show-word-limit
          :disabled="isSubmitting || currentUserId === null"
      />
      <el-button
          type="primary"
          @click="handleAddComment"
          :loading="isSubmitting"
          :disabled="!newCommentContent.trim() || currentUserId === null"
          style="margin-top: 10px;"
      >
        发表评论
      </el-button>
      <!-- Message for non-logged-in users -->
      <p v-if="currentUserId === null" style="color: #f56c6c; font-size: 0.85em; margin-top: 5px;">
        请登录后发表评论。
      </p>
    </div>

    <el-divider />

    <!-- Comments List -->
    <div v-if="isLoading" class="loading-comments">
      <el-skeleton :rows="3" animated />
    </div>
    <div v-else-if="error" class="error-comments">
      <el-alert type="error" :title="error" :closable="false" show-icon />
    </div>
    <div v-else-if="comments.length === 0" class="no-comments">
      <el-empty description="暂无评论，快来抢沙发吧！" />
    </div>
    <div v-else class="comments-list">
      <el-card v-for="comment in comments" :key="comment.id" class="comment-card shadow-hover">
        <template #header>
          <div class="comment-header">
            <!-- Display username using the getter -->
            <span>用户 {{ getUsername(comment.userId) }}</span>
            <el-button
                v-if="canDeleteComment(comment)"
                type="danger"
                link
                size="small"
                @click="handleDeleteComment(comment.id)"
                :loading="deletingCommentId === comment.id"
            >
              删除
            </el-button>
          </div>
        </template>
        <p class="comment-content">{{ comment.content }}</p>
      </el-card>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, reactive } from 'vue';
import {
  getCommentsByProductId,
  createComment,
  deleteComment,
  type Comment,
  type CommentCreatePayload,
} from '../api/comment'; // Adjust path as needed
import { getCurrentUser, getUsernameById } from '../api/user'; // <--- NEW: Import user API functions
import { ElMessage, ElMessageBox, ElInput, ElButton, ElCard, ElDivider, ElAlert, ElEmpty, ElSkeleton } from 'element-plus';

interface Props {
  productId: number;
}

const props = defineProps<Props>();

const comments = ref<Comment[]>([]);
const isLoading = ref(false);
const error = ref<string | null>(null);

const newCommentContent = ref('');
const isSubmitting = ref(false);
const deletingCommentId = ref<number | null>(null);

const currentUserId = ref<number | null>(null); // <--- MODIFIED: Stores the ID of the currently logged-in user, initially null
const userNamesCache = reactive(new Map<number, string>()); // <--- NEW: Cache for userId -> username mapping

const ensureUsernameCached = async (userId: number) => {
  if (userNamesCache.has(userId)) {
    return userNamesCache.get(userId);
  }
  try {
    const response = await getUsernameById(userId);
    if (response.code === '200' && response.data) {
      userNamesCache.set(userId, response.data);
      return response.data;
    } else {
      console.warn(`Failed to fetch username for ID ${userId}: ${response.msg}`);
      const fallback = `未知用户(${userId})`;
      userNamesCache.set(userId, fallback); // Cache fallback to avoid repeated failed calls
      return fallback;
    }
  } catch (e) {
    console.error(`Error fetching username for ID ${userId}:`, e);
    const fallback = `未知用户(${userId})`;
    userNamesCache.set(userId, fallback); // Cache fallback on network/other errors
    return fallback;
  }
};

/**
 * Fetches comments for a given product ID and enriches them with usernames.
 * @param pId The product ID.
 */
const fetchComments = async (pId: number) => {
  if (!pId) {
    comments.value = [];
    return;
  }
  isLoading.value = true;
  error.value = null;
  try {
    const response = await getCommentsByProductId(pId);
    if (response.code === '200') {
      const fetchedComments = response.data.sort((a, b) => b.id - a.id); // Show newest first
      comments.value = fetchedComments;

      // Collect unique user IDs from the fetched comments
      const uniqueUserIds = new Set<number>();
      fetchedComments.forEach(comment => uniqueUserIds.add(comment.userId));

      // Fetch all missing usernames concurrently.
      // Filter out IDs that are already in the cache.
      const fetchPromises = Array.from(uniqueUserIds)
          .filter(userId => !userNamesCache.has(userId))
          .map(userId => ensureUsernameCached(userId));

      // Wait for all username fetches to complete before proceeding
      await Promise.all(fetchPromises);

    } else {
      error.value = response.msg || '加载评论失败';
      comments.value = [];
    }
  } catch (e: any) {
    error.value = e.message || '加载评论时发生错误';
    comments.value = [];
  } finally {
    isLoading.value = false;
  }
};

const handleAddComment = async () => {
  if (!newCommentContent.value.trim() || !props.productId) return;
  if (currentUserId.value === null) {
    ElMessage.warning('请先登录才能发表评论。');
    return;
  }

  isSubmitting.value = true;
  const payload: CommentCreatePayload = {
    productId: props.productId,
    content: newCommentContent.value.trim(),
  };

  try {
    const response = await createComment(payload);
    if (response.code === '200') {
      ElMessage.success(response.msg || '评论发表成功！');
      newCommentContent.value = '';
      await fetchComments(props.productId); // Refresh comments list to show new comment
    } else {
      ElMessage.error(response.msg || '发表评论失败');
    }
  } catch (e: any) {
    ElMessage.error(e.message || '发表评论时发生错误');
  } finally {
    isSubmitting.value = false;
  }
};

/**
 * Handles deleting a comment after confirmation.
 * @param commentId The ID of the comment to delete.
 */
const handleDeleteComment = async (commentId: number) => {
  try {
    await ElMessageBox.confirm('确定要删除这条评论吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    });

    deletingCommentId.value = commentId; // Set ID to show loading state for this specific comment
    const response = await deleteComment(commentId);
    if (response.code === '200') {
      ElMessage.success(response.msg || '评论删除成功！');
      await fetchComments(props.productId); // Refresh comments list
    } else {
      ElMessage.error(response.msg || '删除评论失败');
    }
  } catch (e: any) {
    // If the user cancels the confirmation, e will be 'cancel'. Otherwise, it's an error.
    if (e !== 'cancel') {
      ElMessage.error( (e as Error).message || '删除评论时发生错误');
    }
  } finally {
    deletingCommentId.value = null; // Clear loading state
  }
};

const canDeleteComment = (comment: Comment) => {
  // <--- MODIFIED: Check against actual currentUserId.value
  return currentUserId.value !== null && comment.userId === currentUserId.value;
};

const getUsername = (userId: number) => {
  // If the username is not yet in cache (e.g., still fetching), display a loading message.
  return userNamesCache.get(userId) || `加载中...(${userId})`;
};

// --- Lifecycle Hooks ---

onMounted(async () => {
  try {
    const userResponse = await getCurrentUser();
    if (userResponse.code === '200' && userResponse.data) { // 检查 userResponse.data 确实存在
      // 假设 userResponse.data 是 { id: 1, username: '...' } 这样的对象
      // 我们需要从这个对象中取出 id
      currentUserId.value = userResponse.data.id; // <--- 关键修改在这里！
      console.log('当前登录用户 ID:', currentUserId.value); // 现在会打印数字ID
    } else {
      console.warn('获取当前用户ID失败:', userResponse.msg);
      console.log('当前登录用户 ID: 未登录或获取失败');
    }
  } catch (e) {
    console.error('获取当前用户ID时发生错误:', e);
    console.log('当前登录用户 ID: 获取过程中出错');
  }

  if (props.productId) {
    await fetchComments(props.productId);
  }
});

// Watch for changes in productId prop to refetch comments
watch(
    () => props.productId,
    async (newProductId) => {
      if (newProductId) {
        await fetchComments(newProductId);
      } else {
        // Clear comments and cache if productId becomes invalid (e.g., 0 or null)
        comments.value = [];
        userNamesCache.clear(); // <--- NEW: Clear cache too
      }
    },
    { immediate: false } // 'immediate: true' would call it on mount too, but onMounted handles initial load
);
</script>

<style scoped>
.comments-container {
  margin-top: 30px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.comments-container h2 {
  font-size: 1.8rem;
  color: #303133;
  margin-bottom: 20px;
  border-bottom: 1px solid #ebeef5;
  padding-bottom: 10px;
}

.add-comment-form {
  margin-bottom: 20px;
}

.loading-comments,
.error-comments,
.no-comments {
  padding: 20px;
  text-align: center;
}

.comments-list {
  margin-top: 20px;
}

.comment-card {
  margin-bottom: 15px;
  border: 1px solid #ebeef5;
}

.comment-card .el-card__header {
  padding: 10px 15px;
  background-color: #f9fafc;
}

.comment-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 0.9rem;
  color: #606266;
}

.comment-content {
  font-size: 1rem;
  color: #303133;
  line-height: 1.6;
  white-space: pre-wrap; /* Preserve line breaks in comments */
}

.shadow-hover:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
}
</style>
<script setup lang="ts">
import { ref, watch } from "vue";
import { ElMessage, ElLoading } from "element-plus";
import { updateProduct, adjustProductStockpile } from "../../api/product";
import { uploadImage } from "../../api/tools";

interface Product {
    id: number;
    title: string;
    price: number;
    rate: number;
    description: string;
    cover: string;
    detail: string;
    specifications: any[];
    amount?: number;
    frozen?: number;
}

const props = defineProps({
    visible: Boolean,
    product: Object as () => Product | null,
});

const emit = defineEmits(["close"]);

const editProductForm = ref<Product>({
    id: 0,
    title: "",
    price: 0,
    rate: 0,
    description: "",
    cover: "",
    detail: "",
    specifications: [],
    amount: 0,
    frozen: 0,
});

watch(
    () => props.product,
    (newProduct) => {
        if (newProduct) {
            editProductForm.value = { ...newProduct };
        }
    }
);

const adjustStockPile = async (productId: string, stockpile: number) => {
    try {
        const response = await adjustProductStockpile({
            productId: productId,
            amount: stockpile,
        });
        if (response.code === "200") {
            ElMessage.success("库存调整成功！");
        } else {
            ElMessage.error(response.msg || "调整商品库存失败。");
        }
    } catch (e: any) {
        ElMessage.error(e.message || "发生了一个意外错误。");
    }
};

const addSpec = () => {
    const lastSpecification =
        editProductForm.value.specifications[
            editProductForm.value.specifications.length - 1
        ];

    let newId: number;
    if (editProductForm.value.specifications.length === 0) {
        newId = 1001;
    } else {
        newId = lastSpecification.id + 1;
    }
    editProductForm.value.specifications.push({
        id: newId,
        item: "",
        value: "",
        productId: editProductForm.value.id.toString(),
    });
};

const removeSpec = (index: number) => {
    editProductForm.value.specifications.splice(index, 1);
};

const imageFileList = ref([]); // 用于存储上传的图片文件列表
const coverUploadError = ref(""); // 用于存储上传封面时的错误信息

// 上传封面之前的校验
const beforeCoverUpload = (file: File) => {
    const isJPG =
        file.type === "image/jpeg" ||
        file.type === "image/png" ||
        file.type === "image/gif";
    const isLt2M = file.size / 1024 / 1024 < 2;

    if (!isJPG) {
        ElMessage.error("上传封面图片只能是 JPG/PNG/GIF 格式!");
        return false;
    }
    if (!isLt2M) {
        ElMessage.error("上传封面图片大小不能超过 2MB!");
        return false;
    }
    return true;
};

// 删除图片时的处理
const handleRemove = () => {
    editProductForm.value.cover = ""; // 清空封面 URL
    imageFileList.value = []; // 清空文件列表
};

// 超过文件数量限制时的处理
const handleExceed = () => {
    ElMessage.warning(`当前限制选择 1 个文件`);
};

// 上传封面图片
const uploadCover = async (file: File) => {
    const loading = ElLoading.service({
        lock: true,
        text: "上传封面中...",
        background: "rgba(0, 0, 0, 0.7)",
    });

    try {
        const formData = new FormData();
        formData.append("file", file);

        const res = await uploadImage(formData);

        if (res.data.code === "200") {
            console.log("封面上传成功，URL:", res.data.data);
            // 尝试解码 URL
            try {
                editProductForm.value.cover = decodeURIComponent(res.data.data);
            } catch (e) {
                console.warn("URL解码失败:", e);
                editProductForm.value.cover = res.data.data; // 如果解码失败，仍然使用原始 URL
            }
            coverUploadError.value = "";
            return true;
        } else {
            console.error("封面上传失败，响应:", res);
            coverUploadError.value =
                "封面上传失败: " + (res.data.msg || "Unknown error");
            ElMessage.error({
                message: coverUploadError.value,
                type: "error",
                center: true,
            });
            return false;
        }
    } catch (e: any) {
        coverUploadError.value = "封面上传过程中发生错误，请重试。";
        ElMessage.error(coverUploadError.value, e.message);
    } finally {
        loading.close();
    }
};

// 提交编辑时，处理图片上传
const submitEdit = async () => {
    try {
        // 验证规格是否填写完整
        const incompleteSpecs = editProductForm.value.specifications.filter(
            (spec) => !spec.item.trim() || !spec.value.trim()
        );

        if (incompleteSpecs.length > 0) {
            ElMessage.error("请填写完整的规格项和规格值！");
            return;
        }

        if (imageFileList.value.length > 0) {
            const file = (imageFileList.value[0] as any).raw;
            console.log(file);
            await uploadCover(file); // 上传封面
        }

        if (editProductForm.value.amount != props.product?.amount) {
            adjustStockPile(
                editProductForm.value.id.toString(),
                editProductForm.value.amount || 0
            );
        }

        const response = await updateProduct(editProductForm.value);
        if (response.code === "200") {
            emit("close");
            ElMessage.success("更新成功！");
        } else {
            ElMessage.error(response.msg || "更新商品失败。");
        }
    } catch (e: any) {
        ElMessage.error(e.message || "发生了一个意外错误。");
    }
};

const handleClose = () => {
    emit("close");
};
</script>

<template>
    <el-dialog
        title="编辑商品"
        v-model="props.visible"
        width="50%"
        :before-close="handleClose"
    >
        <el-form :model="editProductForm" label-width="100px">
            <el-form-item label="商品名称">
                <el-input v-model="editProductForm.title"></el-input>
            </el-form-item>
            <el-form-item label="价格">
                <el-input-number
                    v-model="editProductForm.price"
                    :min="0"
                ></el-input-number>
            </el-form-item>
            <el-form-item label="评分">
                <el-input-number
                    v-model="editProductForm.rate"
                    :min="0"
                    :max="10"
                ></el-input-number>
            </el-form-item>
            <el-form-item label="描述">
                <el-input
                    type="textarea"
                    v-model="editProductForm.description"
                ></el-input>
            </el-form-item>
            <el-form-item label="库存">
                <el-input-number
                    v-model="editProductForm.amount"
                    :min="0"
                ></el-input-number>
            </el-form-item>
            <el-form-item label="封面">
                <el-upload
                    ref="upload"
                    v-model:file-list="imageFileList"
                    :limit="1"
                    :on-exceed="handleExceed"
                    :on-remove="handleRemove"
                    class="avatar-uploader"
                    list-type="picture-card"
                    :auto-upload="false"
                    :before-upload="beforeCoverUpload"
                    accept="image/*"
                >
                    <template #trigger>
                        <div class="upload-content">
                            <el-icon class="upload-icon"
                                ><upload-filled
                            /></el-icon>
                            <div class="upload-text">
                                <p class="main-text">点击上传封面</p>
                                <p class="sub-text">建议尺寸 1:1，最大2MB</p>
                            </div>
                        </div>
                    </template>
                </el-upload>
                <p v-if="coverUploadError" class="error-message">
                    {{ coverUploadError }}
                </p>
            </el-form-item>
            <el-form-item label="详情">
                <el-input
                    type="textarea"
                    v-model="editProductForm.detail"
                ></el-input>
            </el-form-item>
            <el-form-item label="规格">
                <div
                    v-for="(spec, index) in editProductForm.specifications"
                    :key="spec.id"
                    class="spec-item"
                >
                    <el-input
                        v-model="spec.item"
                        placeholder="规格项"
                        style="width: 45%; margin-right: 5px"
                    ></el-input>
                    <el-input
                        v-model="spec.value"
                        placeholder="规格值"
                        style="width: 45%; margin-right: 5px"
                    ></el-input>
                    <el-button
                        type="danger"
                        @click="removeSpec(index)"
                        style="margin-left: 5px"
                        >删除</el-button
                    >
                </div>
                <el-button
                    type="success"
                    @click="addSpec"
                    style="
                        margin-left: auto;
                        margin-bottom: auto;
                        margin-right: auto;
                    "
                    >添加规格</el-button
                >
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
            <el-button @click="handleClose">取消</el-button>
            <el-button type="primary" @click="submitEdit">确定</el-button>
        </div>
    </el-dialog>
</template>

<style scoped>
.avatar-uploader {
    width: 100%;
    display: flex;
    justify-content: flex-start;
}

.avatar-uploader :deep(.el-upload) {
    width: 200px;
    height: 200px;
    border: 2px dashed #dcdfe6;
    border-radius: 8px;
    transition: border-color 0.3s;
    margin-bottom: 10px;
}

.avatar-uploader :deep(.el-upload):hover {
    border-color: #409eff;
}

.upload-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    padding: 20px;
}

.upload-icon {
    font-size: 40px;
    color: #c0c4cc;
    margin-bottom: 12px;
}

.upload-text {
    text-align: center;
}

.upload-text .main-text {
    color: #303133;
    margin: 0 0 4px;
    font-weight: 500;
}

.upload-text .sub-text {
    color: #909399;
    margin: 0;
    font-size: 12px;
}
.spec-item {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}
</style>

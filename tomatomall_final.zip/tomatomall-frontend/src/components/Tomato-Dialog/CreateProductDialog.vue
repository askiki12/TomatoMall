<template>
    <el-dialog
        title="创建商品"
        v-model="props.visible"
        width="50%"
        :before-close="handleClose"
    >
        <el-form :model="addProductForm" label-width="100px">
            <el-form-item label="商品名称">
                <el-input v-model="addProductForm.title"></el-input>
            </el-form-item>
            <el-form-item label="价格">
                <el-input-number
                    v-model="addProductForm.price"
                    :min="0"
                ></el-input-number>
            </el-form-item>
            <el-form-item label="评分">
                <el-input-number
                    v-model="addProductForm.rate"
                    :min="0"
                    :max="10"
                ></el-input-number>
            </el-form-item>
            <el-form-item label="描述">
                <el-input
                    type="textarea"
                    v-model="addProductForm.description"
                ></el-input>
            </el-form-item>
            <el-form-item label="封面">
                <el-upload
                    ref="upload"
                    v-model:file-list="imageFileList"
                    :limit="1"
                    :on-exceed="handleExceed"
                    :on-remove="handleRemove"
                    class="avatar-uploader"
                    list-type="picture-card"
                    :auto-upload="false"
                    :before-upload="beforeCoverUpload"
                    accept="image/*"
                >
                    <template #trigger>
                        <div class="upload-content">
                            <el-icon class="upload-icon"
                                ><upload-filled
                            /></el-icon>
                            <div class="upload-text">
                                <p class="main-text">点击上传封面</p>
                                <p class="sub-text">建议尺寸 1:1，最大2MB</p>
                            </div>
                        </div>
                    </template>
                </el-upload>
                <p v-if="coverUploadError" class="error-message">
                    {{ coverUploadError }}
                </p>
            </el-form-item>
            <el-form-item label="详情">
                <el-input
                    type="textarea"
                    v-model="addProductForm.detail"
                ></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer" style="text-align: right">
            <el-button @click="handleClose">取消</el-button>
            <el-button
                type="primary"
                @click="submitAdd"
                :disabled="!isFormValid"
                >确定</el-button
            >
        </div>
    </el-dialog>
</template>

<script setup lang="ts">
import { ref, watch } from "vue";
import { ElMessage, ElLoading } from "element-plus";
import { createProduct } from "../../api/product";
import { uploadImage } from "../../api/tools";
import { UploadFilled } from "@element-plus/icons-vue";

interface Product {
    title: string;
    price: number;
    rate: number;
    description: string;
    cover: string;
    detail: string;
    specifications: any[];
}

const props = defineProps({
    visible: Boolean,
});

const emit = defineEmits(["close"]);

const addProductForm = ref<Product>({
    title: "",
    price: 0,
    rate: 0,
    description: "",
    cover: "",
    detail: "",
    specifications: [],
});

const isFormValid = ref(false);

watch(
    () => ({
        title: addProductForm.value.title,
        price: addProductForm.value.price,
        rate: addProductForm.value.rate,
    }),
    ({ title, price, rate }) => {
        isFormValid.value = !!title && price > 0 && rate > 0;
    },
    { deep: true }
);

const imageFileList = ref([]);
const coverUploadError = ref("");

const beforeCoverUpload = (file: File) => {
    const isJPG =
        file.type === "image/jpeg" ||
        file.type === "image/png" ||
        file.type === "image/gif";
    const isLt2M = file.size / 1024 / 1024 < 2;

    if (!isJPG) {
        ElMessage.error("上传封面图片只能是 JPG/PNG/GIF 格式!");
        return false;
    }
    if (!isLt2M) {
        ElMessage.error("上传封面图片大小不能超过 2MB!");
        return false;
    }
    return true;
};

const handleRemove = () => {
    addProductForm.value.cover = ""; // Clear the URL
    imageFileList.value = [];
};

const handleExceed = () => {
    ElMessage.warning(`当前限制选择 1 个文件`);
};

const uploadCover = async (file: File) => {
    const loading = ElLoading.service({
        lock: true,
        text: "上传封面中...",
        background: "rgba(0, 0, 0, 0.7)",
    });

    try {
        const formData = new FormData();
        formData.append("file", file);

        const res = await uploadImage(formData);

        if (res.data.code === "200") {
          console.log("封面上传成功，URL:", res.data.data);
          // 尝试解码URL
          try {
            addProductForm.value.cover = decodeURIComponent(res.data.data);
          } catch (e) {
            console.warn("URL解码失败:", e);
            addProductForm.value.cover = res.data; // 如果解码失败，仍然使用原始URL
          }
          coverUploadError.value = '';
          return true;
        } else {
          console.error("封面上传失败，响应:", res);
          coverUploadError.value = '封面上传失败: ' + (res.data.msg || 'Unknown error');
          ElMessage.error({
            message: coverUploadError.value,
            type: 'error',
            center: true,
          });
          return false; // Indicate failure
        }
    } catch (e: any) {
        coverUploadError.value = "封面上传过程中发生错误，请重试。";
        ElMessage.error(coverUploadError.value, e.message);
    } finally {
        loading.close();
    }
};

const submitAdd = async () => {
    try {
        if (imageFileList.value.length > 0) {
            const file = (imageFileList.value[0] as any).raw;
            console.log(file);
            await uploadCover(file); // 上传封面
        }

        const response = await createProduct(addProductForm.value);
        if (response.code === "200") {
            emit("close");
            ElMessage.success("创建成功！");
        } else {
            ElMessage.error(response.msg || "创建商品失败。");
        }
    } catch (e: any) {
        ElMessage.error(e.message || "发生了一个意外错误。");
    }
};

const handleClose = () => {
    emit("close");
};
</script>

<style scoped>
.avatar-uploader {
    width: 100%;
    display: flex;
    justify-content: flex-start;
}

.avatar-uploader :deep(.el-upload) {
    width: 200px;
    height: 200px;
    border: 2px dashed #dcdfe6;
    border-radius: 8px;
    transition: border-color 0.3s;
    margin-bottom: 10px;
}

.avatar-uploader :deep(.el-upload):hover {
    border-color: #409eff;
}

.upload-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    padding: 20px;
}

.upload-icon {
    font-size: 40px;
    color: #c0c4cc;
    margin-bottom: 12px;
}

.upload-text {
    text-align: center;
}

.upload-text .main-text {
    color: #303133;
    margin: 0 0 4px;
    font-weight: 500;
}

.upload-text .sub-text {
    color: #909399;
    margin: 0;
    font-size: 12px;
}

.error-message {
    color: red;
    font-size: 0.8rem;
    margin-top: 5px;
}
</style>

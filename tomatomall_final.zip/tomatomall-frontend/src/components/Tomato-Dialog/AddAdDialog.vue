<script setup lang="ts">
import { ref, watch, defineProps, defineEmits } from "vue";
import { ElMessage, ElLoading, ElForm } from "element-plus";
import { Advertisement, createAdvertisement } from "../../api/advertisement";
import { uploadImage } from "../../api/tools";
import { UploadFilled } from "@element-plus/icons-vue";

const props = defineProps({
    visible: {
        type: Boolean,
        default: false,
    },
    productId: {
        type: String,
        required: true, // 确保必须传入 productId
    },
});

const emit = defineEmits(["update:visible", "submit"]);

const dialogVisible = ref(false);
const formRef = ref<InstanceType<typeof ElForm> | null>(null);

const addAdForm = ref<Advertisement>({
    id: 0,
    title: "",
    content: "",
    imgUrl: "",
    productId: "", // 初始化为空，后续通过 watch 赋值
});

const imageFileList = ref([]);
const coverUploadError = ref("");

const rules = {
    title: [{ required: true, message: "标题不能为空", trigger: "blur" }],
    content: [{ required: true, message: "内容不能为空", trigger: "blur" }],
    productId: [{ required: true, message: "产品ID不能为空", trigger: "blur" }],
};

watch(
    () => props.visible,
    (newVal) => {
        dialogVisible.value = newVal;
        if (newVal) {
            // 重置表单数据，但保留 productId
            addAdForm.value = {
                id: 0,
                title: "",
                content: "",
                imgUrl: "",
                productId: props.productId, // 使用传入的 productId
            };
            imageFileList.value = [];
        }
    }
);

watch(
    () => props.productId,
    (newVal) => {
        // 监听 productId 的变化，并更新 addAdForm 中的 productId
        addAdForm.value.productId = newVal;
    }
);

const beforeCoverUpload = (file: File) => {
    const isJPG =
        file.type === "image/jpeg" ||
        file.type === "image/png" ||
        file.type === "image/gif";
    const isLt2M = file.size / 1024 / 1024 < 2;

    if (!isJPG) {
        ElMessage.error("上传图片只能是 JPG/PNG/GIF 格式!");
        return false;
    }
    if (!isLt2M) {
        ElMessage.error("上传图片大小不能超过 2MB!");
        return false;
    }
    return true;
};

const handleRemove = () => {
    addAdForm.value.imgUrl = ""; // Clear the URL
    imageFileList.value = [];
};

const handleExceed = () => {
    ElMessage.warning(`当前限制选择 1 个文件`);
};

const uploadCover = async (file: File) => {
    const loading = ElLoading.service({
        lock: true,
        text: "上传图片中...",
        background: "rgba(0, 0, 0, 0.7)",
    });

    try {
        const formData = new FormData();
        formData.append("file", file);

        const res = await uploadImage(formData);

        if (res.data.code === "200") {
            console.log("图片上传成功，URL:", res.data.data);
            // 尝试解码URL
            try {
                addAdForm.value.imgUrl = decodeURIComponent(res.data.data);
            } catch (e) {
                console.warn("URL解码失败:", e);
                addAdForm.value.imgUrl = res.data.data; // 如果解码失败，仍然使用原始URL
            }
            coverUploadError.value = "";
            return true;
        } else {
            console.error("图片上传失败，响应:", res);
            coverUploadError.value =
                "图片上传失败: " + (res.data.msg || "Unknown error");
            ElMessage.error({
                message: coverUploadError.value,
                type: "error",
                center: true,
            });
            return false; // Indicate failure
        }
    } catch (e: any) {
        coverUploadError.value = "图片上传过程中发生错误，请重试。";
        ElMessage.error(coverUploadError.value, e.message);
    } finally {
        loading.close();
    }
};

const handleClose = () => {
    console.log("Closing dialog...");
    emit("update:visible", false);
    formRef.value?.resetFields();
};

const handleSubmit = async () => {
    formRef.value?.validate(async (valid) => {
        if (valid) {
            try {
                if (imageFileList.value.length > 0) {
                    const file = (imageFileList.value[0] as any).raw;
                    console.log(file);
                    await uploadCover(file); // 上传图片
                }

                // 调用 createAdvertisement API
                const response = await createAdvertisement({
                    title: addAdForm.value.title,
                    content: addAdForm.value.content,
                    imgUrl: addAdForm.value.imgUrl,
                    productId: addAdForm.value.productId,
                });

                // 处理响应
                if (response.code === "200") {
                    ElMessage.success("广告创建成功！");
                    emit("submit", addAdForm.value); // 可选：通知父组件提交成功
                    handleClose(); // 关闭对话框
                } else {
                    ElMessage.error(response.msg || "广告创建失败！");
                }
            } catch (error: any) {
                ElMessage.error(error.message || "发生了一个意外错误。");
            }
        } else {
            ElMessage.error("请填写完整的信息！");
        }
    });
};
</script>

<template>
    <el-dialog
        title="创建广告"
        v-model="dialogVisible"
        width="50%"
        :before-close="handleClose"
    >
        <el-form
            ref="formRef"
            :model="addAdForm"
            label-width="120px"
            :rules="rules"
        >
            <el-form-item label="标题" prop="title">
                <el-input
                    v-model="addAdForm.title"
                    placeholder="请输入广告标题"
                ></el-input>
            </el-form-item>
            <el-form-item label="内容" prop="content">
                <el-input
                    type="textarea"
                    v-model="addAdForm.content"
                    placeholder="请输入广告内容"
                ></el-input>
            </el-form-item>
            <el-form-item label="图片">
                <el-upload
                    ref="upload"
                    v-model:file-list="imageFileList"
                    :limit="1"
                    :on-exceed="handleExceed"
                    :on-remove="handleRemove"
                    class="avatar-uploader"
                    list-type="picture-card"
                    :auto-upload="false"
                    :before-upload="beforeCoverUpload"
                    accept="image/*"
                >
                    <template #trigger>
                        <div class="upload-content">
                            <el-icon class="upload-icon"
                                ><upload-filled
                            /></el-icon>
                            <div class="upload-text">
                                <p class="main-text">点击上传图片</p>
                                <p class="sub-text">建议尺寸 1:1，最大2MB</p>
                            </div>
                        </div>
                    </template>
                </el-upload>
                <p v-if="coverUploadError" class="error-message">
                    {{ coverUploadError }}
                </p>
            </el-form-item>
            <el-form-item label="产品ID" prop="productId">
                <el-input
                    v-model="addAdForm.productId"
                    placeholder="关联的产品ID"
                    disabled
                ></el-input>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="handleClose">取消</el-button>
                <el-button type="primary" @click="handleSubmit">创建</el-button>
            </span>
        </template>
    </el-dialog>
</template>

<style scoped>
.avatar-uploader {
    width: 100%;
    display: flex;
    justify-content: flex-start;
}

.avatar-uploader :deep(.el-upload) {
    width: 200px;
    height: 200px;
    border: 2px dashed #dcdfe6;
    border-radius: 8px;
    transition: border-color 0.3s;
    margin-bottom: 10px;
}

.avatar-uploader :deep(.el-upload):hover {
    border-color: #409eff;
}

.upload-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    padding: 20px;
}

.upload-icon {
    font-size: 40px;
    color: #c0c4cc;
    margin-bottom: 12px;
}

.upload-text {
    text-align: center;
}

.upload-text .main-text {
    color: #303133;
    margin: 0 0 4px;
    font-weight: 500;
}

.upload-text .sub-text {
    color: #909399;
    margin: 0;
    font-size: 12px;
}

.error-message {
    color: red;
    font-size: 0.8rem;
    margin-top: 5px;
}
</style>

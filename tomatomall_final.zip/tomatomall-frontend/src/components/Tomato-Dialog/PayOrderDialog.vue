<script setup lang="ts">
import { ref } from "vue";
import { ElMessage } from "element-plus";
import {
    checkout,
    pay,
    status,
    CheckoutPayload,
    deleteCartItem,
} from "../../api/cart";

const submitted = ref(false);
const paying = ref(false);
const orderId = ref<number>(0);
const amount = ref<number>(0);
const paymentPage = ref<string>("");
const orderStatus = ref<string>("");

const props = defineProps({
    visible: Boolean,
    amount: { type: Number, default: 0 },
    checkoutIds: {
        type: Array as () => string[],
        default: () => [],
    },
});

const emit = defineEmits(["close"]);

const formInfo = ref({
    name: "",
    phone: "",
    address: "",
});

const checkoutPayload = ref<CheckoutPayload>({
    cartItemIds: props.checkoutIds,
    addressInfo: formInfo.value,
    paymentMethod: "ALIPAY",
});

const handleCheckout = async () => {
    try {
        if (
            !formInfo.value.name ||
            !formInfo.value.phone ||
            !formInfo.value.address
        ) {
            ElMessage.error("请填写完整的收货信息！");
            return;
        }
        amount.value = props.amount;
        checkoutPayload.value.cartItemIds = props.checkoutIds;
        const response = await checkout(checkoutPayload.value);
        if (response.code === "200") {
            ElMessage.success("提交订单成功！");
            submitted.value = true;
            orderId.value = response.data
                ? response.data.orderId
                : orderId.value;
            amount.value = response.data
                ? response.data.totalAmount
                : amount.value;
            console.log("支付信息：", response.data);
        } else {
            ElMessage.error("支付失败，请重试！");
        }
    } catch (error: any) {
        ElMessage.error(error.message || "网络错误，请稍后再试！");
    }
};

const handlePay = async () => {
    try {
        const response = await pay(orderId.value);
        if (response.code === "200") {
            paymentPage.value = response.data ? response.data.paymentForm : "";
            const paymentUrl = `/payment-container.html?content=${encodeURIComponent(paymentPage.value)}`;
            window.open(paymentUrl, "_blank");
            paying.value = true;
            fetchOrderStatus();
            console.log("支付页面：", paymentPage.value);
        } else {
            ElMessage.error("支付失败，请重试！");
        }
    } catch (error: any) {
        ElMessage.error(error.message || "网络错误，请稍后再试！");
    }
};

const fetchOrderStatus = async () => {
    let pendingMessage = null; // 用于存储“支付处理中”的消息实例

    while (paying.value) {
        console.log("轮询订单状态...");
        try {
            const response = await status(orderId.value);
            console.log("订单状态：", response);
            if (response.code === "200") {
                orderStatus.value = response.data ? response.data : "";
                console.log("订单状态：", orderStatus.value);

                if (orderStatus.value === "SUCCESS") {
                    if (pendingMessage) {
                        pendingMessage.close(); // 关闭“支付处理中”的提示
                    }
                    ElMessage.success("支付成功！");
                    window.location.reload();
                    emit("close");
                    return;
                } else if (orderStatus.value === "PENDING") {
                    if (!pendingMessage) {
                        // 如果之前没有显示“支付处理中”，则显示
                        pendingMessage = ElMessage.info({
                            message: "支付处理中，请稍等...",
                            duration: 0,
                        });
                    }
                    await new Promise((resolve) => setTimeout(resolve, 5000));
                } else if (orderStatus.value === "TIMEOUT") {
                    if (pendingMessage) {
                        pendingMessage.close(); // 关闭“支付处理中”的提示
                    }
                    ElMessage.error("支付已过期！");
                    emit("close");
                    return;
                } else if (orderStatus.value === "FAILED") {
                    if (pendingMessage) {
                        pendingMessage.close(); // 关闭“支付处理中”的提示
                    }
                    ElMessage.error("支付失败，请重试！");
                    emit("close");
                    return;
                }
            } else {
                if (pendingMessage) {
                    pendingMessage.close(); // 关闭“支付处理中”的提示
                }
                ElMessage.error("获取订单状态失败，请重试！");
                await new Promise((resolve) => setTimeout(resolve, 5000));
            }
        } catch (error: any) {
            if (pendingMessage) {
                pendingMessage.close(); // 关闭“支付处理中”的提示
            }
            ElMessage.error(error.message || "网络错误，请稍后再试！");
            await new Promise((resolve) => setTimeout(resolve, 5000));
        }
    }
};

const handleClose = () => {
    emit("close");
};
</script>

<template>
    <el-dialog
        title="支付订单"
        v-model="props.visible"
        width="50%"
        :before-close="handleClose"
    >
        <div v-if="!submitted">
            <el-form :model="formInfo" label-width="80px">
                <el-form-item label="姓名">
                    <el-input
                        v-model="formInfo.name"
                        placeholder="请输入姓名"
                    ></el-input>
                </el-form-item>
                <el-form-item label="电话">
                    <el-input
                        v-model="formInfo.phone"
                        placeholder="请输入电话"
                    ></el-input>
                </el-form-item>
                <el-form-item label="地址">
                    <el-input
                        v-model="formInfo.address"
                        placeholder="请输入地址"
                    ></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer" style="text-align: right">
                <el-button @click="handleClose">取消</el-button>
                <el-button type="primary" @click="handleCheckout"
                    >确定</el-button
                >
            </div>
        </div>
        <div v-else-if="!paying">
            <h3>订单金额：{{ amount }} 元</h3>
            <el-button type="primary" @click="handlePay">支付</el-button>
        </div>
        <!-- <div v-else-if="paying">
            <div v-if="paymentPage === ''">
                <h3>支付中，请稍等...</h3>
            </div>
            <div v-else>
                <iframe
                    title="支付界面"
                    :srcdoc="paymentPage"
                    width="100%"
                    height="500px"
                ></iframe>
            </div>
        </div> -->

        <div v-else>
            <h3>支付失败，请重试！</h3>
        </div>
    </el-dialog>
</template>


<template>
    <div class="avatar-uploader">
        <el-upload
            ref="upload"
            v-model:file-list="imageFileList"
            :limit="1"
            :on-exceed="handleExceed"
            :on-remove="handleRemove"
            class="avatar-uploader"
            list-type="picture-card"
            :auto-upload="false"
            :before-upload="beforeAvatarUpload"
            accept="image/*"
        >
            <template #trigger>
                <div class="upload-content">
                    <el-icon class="upload-icon"><upload-filled /></el-icon>
                    <div class="upload-text">
                        <p class="main-text">点击上传头像</p>
                        <p class="sub-text">建议尺寸 1:1，最大2MB</p>
                    </div>
                </div>
            </template>
        </el-upload>
        <p v-if="avatarUploadError" class="error-message">
            {{ avatarUploadError }}
        </p>
        <button @click="uploadAvatar" class="upload-button">上传头像</button>
    </div>
</template>

<script setup>
import { ref, watch } from "vue";
import { ElMessage } from "element-plus";
import { uploadImage } from "../api/tools";
import { UploadFilled } from "@element-plus/icons-vue";

const props = defineProps({
    avatar: {
        type: String,
        default: "",
    },
});

const emit = defineEmits(["update:avatar", "upload-success"]);
const imageFileList = ref([]);
const avatarUploadError = ref("");
const upload = ref(null);

const beforeAvatarUpload = (file) => {
    const isJPG =
        file.type === "image/jpeg" ||
        file.type === "image/png" ||
        file.type === "image/gif";
    const isLt2M = file.size / 1024 / 1024 < 2;

    if (!isJPG) {
        ElMessage.error("上传头像图片只能是 JPG/PNG/GIF 格式!");
        return false;
    }
    if (!isLt2M) {
        ElMessage.error("上传头像图片大小不能超过 2MB!");
        return false;
    }
    return true;
};

const handleRemove = () => {
    emit("update:avatar", "");
    imageFileList.value = [];
};

const handleExceed = () => {
    ElMessage.warning(`当前限制选择 1 个文件`);
};

const uploadAvatar = async () => {
    if (imageFileList.value.length === 0) {
        ElMessage.error("请选择一个头像文件");
        return;
    }

    const file = imageFileList.value[0].raw;
    const loading = ElMessage({
        message: "上传头像中...",
        type: "info",
        duration: 0,
        showClose: false,
    });

    try {
        const formData = new FormData();
        formData.append("file", file);

        const res = await uploadImage(formData);

        if (res.code === "200") {
            emit("update:avatar", res.data.data);
            emit("upload-success");
            avatarUploadError.value = "";
            ElMessage.success("头像上传成功！");
        } else {
            avatarUploadError.value =
                "头像上传失败: " + (res.msg || "Unknown error");
            ElMessage.error(avatarUploadError.value);
        }
    } catch (error) {
        avatarUploadError.value = "头像上传过程中发生错误，请重试。";
        ElMessage.error(avatarUploadError.value);
    } finally {
        loading.close();
    }
};

watch(
    () => props.avatar,
    (newAvatar) => {
        if (!newAvatar) {
            imageFileList.value = [];
        }
    }
);
</script>

<style scoped>
.avatar-uploader {
    width: 100%;
    display: flex;
    justify-content: flex-start;
}

.avatar-uploader :deep(.el-upload) {
    width: 200px;
    height: 200px;
    border: 2px dashed #dcdfe6;
    border-radius: 8px;
    transition: border-color 0.3s;
    margin-bottom: 10px;
}

.avatar-uploader :deep(.el-upload):hover {
    border-color: #409eff;
}

.upload-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    padding: 20px;
}

.upload-icon {
    font-size: 40px;
    color: #c0c4cc;
    margin-bottom: 12px;
}

.upload-text {
    text-align: center;
}

.upload-text .main-text {
    color: #303133;
    margin: 0 0 4px;
    font-weight: 500;
}

.upload-text .sub-text {
    color: #909399;
    margin: 0;
    font-size: 12px;
}

.error-message {
    color: red;
    font-size: 0.8rem;
    margin-top: 5px;
}
</style>

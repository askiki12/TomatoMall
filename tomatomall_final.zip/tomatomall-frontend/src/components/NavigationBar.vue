<script setup lang="ts">
import { ElMenu, ElMenuItem, ElButton, ElMessage } from "element-plus";
import { useRouter } from "vue-router";
import { ref, onMounted } from "vue";

const isAdmin = ref(false);

const router = useRouter();

// 定义一个函数来更新 isAdmin 的值
const updateIsAdmin = () => {
    isAdmin.value = sessionStorage.getItem("role") === "admin";
};

// 定义一个变量来存储当前的时间间隔（毫秒）
let interval = 1 * 1 * 150; // 间隔为 150 毫秒

onMounted(() => {
    setTimeout(() => {
        updateIsAdmin();
    }, interval);
});

const handleLogout = () => {
    // 清除 token 或用户信息（可选）
    sessionStorage.removeItem("role"); // 清除角色信息
    sessionStorage.removeItem("token"); // 清除 token
    sessionStorage.removeItem("username"); // 清除用户名
    // 显示退出登录提示
    ElMessage({
        message: "退出登录成功",
        type: "success",
        duration: 2000,
    });
    // 跳转到登录页面
    router.push("/login");
};

const handleProfile = () => {
    updateIsAdmin(); // 确保在点击时也更新 isAdmin 的值
    console.log("isAdmin", isAdmin.value);
    router.push("/profile");
};
</script>

<template>
    <div class="nav-bar-container">
        <el-menu class="nav-bar" mode="horizontal" :router="true">
            <el-menu-item index="/home">番茄书城</el-menu-item>
            <el-menu-item index="/cart">购物车</el-menu-item>
            <el-menu-item index="/warehouse" v-if="isAdmin"
                >库存管理</el-menu-item
            >
            <el-menu-item index="/advertisement" v-if="isAdmin"
                >广告管理</el-menu-item
            >

            <ElButton
                type="primary"
                @click="handleProfile"
                class="profile-button"
                >个人详情</ElButton
            >
            <ElButton type="danger" @click="handleLogout" class="logout-button"
                >退出登录</ElButton
            >
        </el-menu>
    </div>
</template>

<style scoped>
.nav-bar-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 1000;
    height: 60px;
    background-color: #fff;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
}

.nav-bar {
    position: relative; /*  关键：设置相对定位，为绝对定位的按钮提供参考 */
    display: flex;
    align-items: center;
    width: 100%;
    margin: 0 auto;
    height: 100%;
    padding: 0 10px;
    box-sizing: border-box;
}

.profile-button {
    position: absolute !important;
    top: 50% !important;
    right: 110px !important; /* 调整位置，使按钮相邻 */
    transform: translateY(-50%) !important;
    z-index: 1 !important;
}

.logout-button {
    position: absolute !important; /*  关键：使用绝对定位 */
    top: 50% !important; /* 垂直居中 */
    right: 10px !important; /* 距离右侧 10px */
    transform: translateY(-50%) !important; /* 修正垂直居中 */
    z-index: 1 !important; /* 确保在其他元素之上 */
}

/* 适配element-plus的样式 */
.nav-bar >>> .el-menu-item {
    height: 60px;
    line-height: 60px;
}
</style>

<template>
    <div class="add-to-cart-bar">
        <button
            @click="handleAddToCart"
            :disabled="loading"
            class="add-to-cart-button"
        >
            <span v-if="!loading">加入购物车</span>
            <span v-else>Adding...</span>
        </button>

        <!-- Inlined Modal -->
        <div class="modal-overlay" v-if="showAlert">
            <div class="modal">
                <p class="modal-message">{{ alertMessage }}</p>
                <button @click="closeAlert" class="modal-button">OK</button>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { ref, defineProps } from "vue";
import { addToCart } from "../api/cart";

const props = defineProps({
    productId: {
        type: Number,
        required: true,
    },
});

const loading = ref(false);
const showAlert = ref(false);
const alertMessage = ref("");

const handleAddToCart = async () => {
    loading.value = true;
    try {
        const response = addToCart({
            productId: String(props.productId),
            quantity: 1,
        });
        if ((await response).code === "200") {
            alertMessage.value = "成功加入购物车!";
            showAlert.value = true;
        } else {
            alertMessage.value = "商品库存不足";
            showAlert.value = true;
        }
    } catch (error: any) {
        console.error("添加购物车失败:", error);
        alertMessage.value = "Failed to add to cart. Please try again.";
        showAlert.value = true;
    } finally {
        loading.value = false;
    }
};

const closeAlert = () => {
    showAlert.value = false;
};
</script>

<style scoped>
.add-to-cart-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #fff;
    padding: 10px;
    box-shadow: 0px -2px 5px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 100;
}

.add-to-cart-button {
    background-color: orange;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    width: 200px;
}

.add-to-cart-button:disabled {
    background-color: #ccc;
    cursor: not-allowed;
}

/* Modal Styles (Inlined) */
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.modal {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    text-align: center;
    min-width: 300px;
}

.modal-message {
    font-size: 1.5em;
    margin-bottom: 20px;
}

.modal-button {
    background-color: #4caf50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 1em;
}
</style>
